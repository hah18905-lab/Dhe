@echo off
cd /d "%~dp0backend"
python -m pip install -r requirements.txt
python -m uvicorn api:app --host 127.0.0.1 --port 8000
