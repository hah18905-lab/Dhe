@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul
cd /d "%~dp0"

title ASTRA - НАДЕЖНЫЙ ЗАПУСК

echo.
echo ==================================================
echo             ASTRA — ЗАПУСК
echo ==================================================
echo.

REM ===== Python =====
set "PY="
where py >nul 2>nul
if not errorlevel 1 set "PY=py -3"
if not defined PY (
    where python >nul 2>nul
    if not errorlevel 1 set "PY=python"
)
if not defined PY (
    echo [ОШИБКА] Python не найден.
    echo Установите Python 3.11+ и добавьте его в PATH.
    pause
    exit /b 1
)
echo [OK] Python найден: %PY%

REM ===== Node/npm =====
where npm >nul 2>nul
if errorlevel 1 (
    echo [ОШИБКА] Node.js / npm не найден.
    echo Установите Node.js LTS и перезапустите ASTRA.
    pause
    exit /b 1
)
set "NPM=npm.cmd"
echo [OK] npm найден.

REM ===== Python environment: try venv, but never make it a hard requirement =====
echo.
echo [1/5] Подготовка Python-окружения...
if not exist "backend\.venv\Scripts\python.exe" (
    %PY% -m venv "backend\.venv" >nul 2>nul
)
if exist "backend\.venv\Scripts\python.exe" (
    set "ASTRA_PY=%~dp0backend\.venv\Scripts\python.exe"
    echo [OK] Используется отдельное окружение проекта.
) else (
    set "ASTRA_PY=%PY%"
    echo [ПРЕДУПРЕЖДЕНИЕ] Не удалось создать .venv — используется системный Python.
)

REM ===== Backend dependencies only if imports are missing =====
echo.
echo [2/5] Проверка зависимостей ядра...
%ASTRA_PY% -c "import fastapi,uvicorn,pydantic" >nul 2>nul
if errorlevel 1 (
    echo [INFO] Устанавливаем зависимости ядра...
    %ASTRA_PY% -m pip install --disable-pip-version-check -r "backend\requirements.txt"
    if errorlevel 1 (
        echo [ОШИБКА] Не удалось установить зависимости ядра.
        echo Проверьте интернет и попробуйте еще раз.
        pause
        exit /b 1
    )
) else (
    echo [OK] Зависимости ядра уже готовы.
)

REM ===== Frontend dependencies =====
echo.
echo [3/5] Проверка интерфейса...
if not exist "frontend\node_modules\.bin\vite.cmd" (
    echo [INFO] Устанавливаем React/Vite. На первом запуске это может занять немного времени...
    pushd "frontend"
    call %NPM% install --no-audit --no-fund --progress=false
    set "NPM_EXIT=!errorlevel!"
    popd
    if not "!NPM_EXIT!"=="0" (
        echo.
        echo [ОШИБКА] Не удалось установить зависимости интерфейса.
        echo Проверьте интернет, Node.js LTS и права доступа к папке проекта.
        pause
        exit /b 1
    )
) else (
    echo [OK] React/Vite уже установлены.
)

REM ===== Start backend only if not already healthy =====
echo.
echo [4/5] Запуск симуляционного ядра...
powershell -NoProfile -ExecutionPolicy Bypass -Command "try { $r=Invoke-WebRequest -UseBasicParsing -TimeoutSec 1 http://127.0.0.1:8000/api/health; if($r.StatusCode -eq 200){exit 0}else{exit 1} } catch { exit 1 }" >nul 2>nul
if errorlevel 1 (
    start "ASTRA — Ядро" cmd /k "cd /d ""%~dp0backend"" && ""%ASTRA_PY%"" -m uvicorn api:app --host 127.0.0.1 --port 8000"
    set "READY="
    for /L %%I in (1,1,40) do (
        powershell -NoProfile -ExecutionPolicy Bypass -Command "try { $r=Invoke-WebRequest -UseBasicParsing -TimeoutSec 1 http://127.0.0.1:8000/api/health; if($r.StatusCode -eq 200){exit 0}else{exit 1} } catch { exit 1 }" >nul 2>nul
        if not errorlevel 1 (set "READY=1" & goto BACKEND_READY)
        timeout /t 1 /nobreak >nul
    )
    if not defined READY (
        echo [ОШИБКА] Ядро не ответило за 40 секунд.
        echo Откройте окно «ASTRA — Ядро» для точной причины.
        pause
        exit /b 1
    )
) else (
    echo [OK] Ядро уже запущено.
)
:BACKEND_READY
echo [OK] Ядро доступно: http://127.0.0.1:8000

REM ===== Start frontend only if not already responding =====
echo.
echo [5/5] Запуск интерфейса...
powershell -NoProfile -ExecutionPolicy Bypass -Command "try { $r=Invoke-WebRequest -UseBasicParsing -TimeoutSec 1 http://127.0.0.1:5173; if($r.StatusCode -ge 200 -and $r.StatusCode -lt 500){exit 0}else{exit 1} } catch { exit 1 }" >nul 2>nul
if errorlevel 1 (
    start "ASTRA — Интерфейс" cmd /k "cd /d ""%~dp0frontend"" && call npm.cmd run dev -- --host 127.0.0.1 --port 5173"
    set "READY="
    for /L %%I in (1,1,30) do (
        powershell -NoProfile -ExecutionPolicy Bypass -Command "try { $r=Invoke-WebRequest -UseBasicParsing -TimeoutSec 1 http://127.0.0.1:5173; if($r.StatusCode -ge 200 -and $r.StatusCode -lt 500){exit 0}else{exit 1} } catch { exit 1 }" >nul 2>nul
        if not errorlevel 1 (set "READY=1" & goto FRONTEND_READY)
        timeout /t 1 /nobreak >nul
    )
    if not defined READY (
        echo [ПРЕДУПРЕЖДЕНИЕ] Интерфейс еще запускается. Проверьте окно «ASTRA — Интерфейс».
    )
) else (
    echo [OK] Интерфейс уже запущен.
)
:FRONTEND_READY
start "" "http://127.0.0.1:5173"
echo.
echo ==================================================
echo            ASTRA ГОТОВА К РАБОТЕ
echo ==================================================
echo.
echo Не закрывайте окна «ASTRA — Ядро» и «ASTRA — Интерфейс».
echo.
pause
