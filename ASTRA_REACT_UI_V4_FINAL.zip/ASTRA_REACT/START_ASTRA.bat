@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul
cd /d "%~dp0"

title ASTRA - ONE CLICK START

echo.
echo ================================================
echo              ASTRA - ONE CLICK START
echo ================================================
echo.

REM -------------------- Python --------------------
set "PY="
where py >nul 2>nul
if not errorlevel 1 set "PY=py -3"
if not defined PY (
    where python >nul 2>nul
    if not errorlevel 1 set "PY=python"
)
if not defined PY (
    echo [ERROR] Python not found.
    echo Install Python 3.11+ and enable PATH.
    pause
    exit /b 1
)
echo [OK] Python: %PY%

REM -------------------- Node --------------------
where npm >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Node.js / npm not found.
    echo Install Node.js LTS and run again.
    pause
    exit /b 1
)
echo [OK] Node.js / npm found.

REM -------------------- Python environment --------------------
echo.
echo [1/5] Preparing Python environment...
if not exist "backend\.venv\Scripts\python.exe" (
    %PY% -m venv "backend\.venv"
)
if exist "backend\.venv\Scripts\python.exe" (
    set "ASTRA_PY=%~dp0backend\.venv\Scripts\python.exe"
    echo [OK] Virtual environment ready.
) else (
    set "ASTRA_PY=%PY%"
    echo [WARN] Virtual environment unavailable. Using installed Python.
)

%ASTRA_PY% -m pip --version >nul 2>nul
if errorlevel 1 (
    echo [INFO] pip is missing. Enabling pip...
    %ASTRA_PY% -m ensurepip --upgrade
)

REM -------------------- Backend dependencies --------------------
echo.
echo [2/5] Checking backend dependencies...
%ASTRA_PY% -m pip install -r "backend\requirements.txt"
if errorlevel 1 (
    echo [ERROR] Backend dependency installation failed.
    pause
    exit /b 1
)

REM -------------------- Frontend dependencies --------------------
echo.
echo [3/5] Checking frontend dependencies...
if not exist "frontend\node_modules" (
    pushd "frontend"
    call npm install
    set "NPM_EXIT=!errorlevel!"
    popd
    if not "!NPM_EXIT!"=="0" (
        echo [ERROR] React dependency installation failed.
        pause
        exit /b 1
    )
) else (
    echo [OK] React dependencies already installed.
)

REM -------------------- Start backend --------------------
echo.
echo [4/5] Starting simulation backend...
start "ASTRA Backend" cmd /k "cd /d ""%~dp0backend"" && ""%ASTRA_PY%"" -m uvicorn api:app --host 127.0.0.1 --port 8000"

echo Waiting for backend to become ready...
set "READY="
for /L %%I in (1,1,30) do (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "try { $r=Invoke-WebRequest -UseBasicParsing -TimeoutSec 1 http://127.0.0.1:8000/api/health; if ($r.StatusCode -eq 200) { exit 0 } } catch {}; exit 1" >nul 2>nul
    if not errorlevel 1 (
        set "READY=1"
        goto :backend_ready
    )
    timeout /t 1 /nobreak >nul
)

if not defined READY (
    echo.
    echo [ERROR] Backend did not start in time.
    echo Look at the "ASTRA Backend" window for the real Python error.
    pause
    exit /b 1
)

:backend_ready
echo [OK] Backend is online at http://127.0.0.1:8000

REM -------------------- Start frontend --------------------
echo.
echo [5/5] Starting React interface...
start "ASTRA Frontend" cmd /k "cd /d ""%~dp0frontend"" && npm run dev -- --host 127.0.0.1 --port 5173"

echo Waiting for frontend...
for /L %%I in (1,1,20) do (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "try { $r=Invoke-WebRequest -UseBasicParsing -TimeoutSec 1 http://127.0.0.1:5173; if ($r.StatusCode -ge 200 -and $r.StatusCode -lt 500) { exit 0 } } catch {}; exit 1" >nul 2>nul
    if not errorlevel 1 goto :frontend_ready
    timeout /t 1 /nobreak >nul
)

echo [WARN] Frontend did not answer yet. Open it manually after a few seconds.
:frontend_ready
start "" "http://127.0.0.1:5173"

echo.
echo ================================================
echo              ASTRA IS READY
echo ================================================
echo.
echo Frontend: http://127.0.0.1:5173
echo Backend:  http://127.0.0.1:8000/docs
echo.
echo Keep both ASTRA terminal windows open.
echo.
pause
