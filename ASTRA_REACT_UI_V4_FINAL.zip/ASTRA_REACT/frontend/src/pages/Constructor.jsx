import React, { useEffect, useMemo, useState } from 'react'
import { ActionButton, Section, SliderField, StatusPill } from '../components/Ui'
import { environmentFields as fields, environmentPresets as presets, presetDescriptions, toApiSettings } from '../config/environment'

export default function Constructor({ state, onApply, onApplyReset, onApplyStart, onSpeed }) {
  const [settings, setSettings] = useState({ ...state.settings, initial_population: state.settings.initial_population ?? 80 })
  const [dirty, setDirty] = useState(false)

  useEffect(() => {
    setSettings({ ...state.settings, initial_population: state.settings.initial_population ?? 80 })
    setDirty(false)
  }, [state.settings])

  const set = (key, value) => {
    setSettings(current => ({ ...current, [key]: value }))
    setDirty(true)
  }

  const applyPreset = name => {
    setSettings(current => ({ ...current, ...presets[name] }))
    setDirty(true)
  }

  const apiSettings = useMemo(() => toApiSettings(settings), [settings])
  const changed = dirty
  const pop = Number(settings.initial_population ?? 80)

  return (
    <div className="page-grid">
      <div className="hero-row">
        <div>
          <div className="page-kicker">КОНСТРУКТОР · A-17</div>
          <h2 className="page-title">Соберите условия эксперимента</h2>
          <p className="page-description">Меняйте среду до запуска. После применения новые условия становятся частью следующего эксперимента.</p>
        </div>
        <StatusPill tone={changed ? 'warn' : 'good'}>{changed ? 'ЕСТЬ НЕПРИМЕНЁННЫЕ ИЗМЕНЕНИЯ' : 'ПАРАМЕТРЫ СИНХРОНИЗИРОВАНЫ'}</StatusPill>
      </div>

      <Section title="Быстрый выбор среды" subtitle="Готовые сценарии можно выбрать, а затем вручную изменить любой параметр">
        <div className="preset-grid">
          {Object.keys(presets).map(name => (
            <button key={name} className="preset-button" type="button" onClick={() => applyPreset(name)}>
              <span>{name}</span>
              <small>{presetDescriptions[name]}</small>
            </button>
          ))}
        </div>
      </Section>

      <Section title="Параметры планеты" subtitle="0% = минимум модели · 100% = максимум модели. Это нормализованные значения, не физические единицы.">
        <div className="settings-grid">
          {fields.map(([key, label, hint]) => (
            <SliderField
              key={key}
              label={label}
              value={Math.round((Number(settings[key]) || 0) * 100)}
              onChange={v => set(key, v / 100)}
              hint={hint}
            />
          ))}
        </div>
      </Section>

      <div className="two-column">
        <Section title="Параметры системы" subtitle="Настройки эволюционного эксперимента">
          <SliderField label="Сила мутации" value={Number(settings.mutation_strength ?? 0.055) * 100} max={20} step={0.5} onChange={v => set('mutation_strength', v / 100)} hint="амплитуда изменения генома потомка" />
          <SliderField label="Начальная популяция" value={pop} max={200} suffix="" onChange={v => set('initial_population', v)} hint="число организмов в начале нового эксперимента" />
          <SliderField label="Скорость симуляции" value={state.speed} max={10} suffix="×" onChange={v => onSpeed(v)} hint="сколько тиков обрабатывается за цикл интерфейса" />
        </Section>

        <Section title="Запуск эксперимента" subtitle="Выберите, что сделать с подготовленными условиями">
          <div className="apply-card">
            <span>Подготовленная среда</span>
            <strong>{changed ? 'ГОТОВА К ПРИМЕНЕНИЮ' : state.environmentStatus}</strong>
            <small>Начальная популяция: {pop} · Текущая: {state.planet.population}</small>
          </div>

          <div className="button-stack">
            <ActionButton variant="blue" onClick={() => onApply(apiSettings)} disabled={!changed}>Применить изменения</ActionButton>
            <ActionButton variant="blue" onClick={() => onApplyStart(apiSettings)}>Применить и ▶ запустить</ActionButton>
            <ActionButton onClick={() => onApplyReset(apiSettings)}>Применить и начать с паузы</ActionButton>
          </div>

          <div className="formula-note">
            <b>Важно</b>
            <p>Изменения не являются декоративными: после применения они передаются в ядро ASTRA и влияют на доступность воды, ресурсов, риск радиации, устойчивость, энергетический потенциал, решения организмов, рождаемость и выживаемость.</p>
          </div>
        </Section>
      </div>
    </div>
  )
}
