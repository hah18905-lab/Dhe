import React from 'react'

function points(data, key, max, width, height, padX = 32, padTop = 14, padBottom = 22) {
  if (!data.length) return ''
  const innerW = width - padX * 2
  const innerH = height - padTop - padBottom
  return data.map((row, i) => {
    const x = padX + (i / Math.max(1, data.length - 1)) * innerW
    const y = padTop + innerH - (Number(row[key]) / Math.max(1, max)) * innerH
    return `${x.toFixed(1)},${y.toFixed(1)}`
  }).join(' ')
}

export default function Chart({ history }) {
  const width = 900
  const height = 260
  const data = history.slice(-160)
  if (data.length < 2) return <div className="chart-empty">График появится после первого шага симуляции.</div>

  const maxPopulation = Math.max(1, ...data.map(d => Math.max(d.population, d.capacity)))
  const maxGeneration = Math.max(1, ...data.map(d => d.generation))
  return (
    <div className="chart-wrap">
      <svg viewBox={`0 0 ${width} ${height}`} preserveAspectRatio="none" className="chart-svg">
        {[1, 2, 3, 4].map(i => <line key={i} x1="32" x2={width - 32} y1={14 + ((height - 36) * i / 4)} y2={14 + ((height - 36) * i / 4)} className="grid-line" />)}
        <polyline points={points(data, 'capacity', maxPopulation, width, height)} className="chart-capacity" />
        <polyline points={points(data, 'population', maxPopulation, width, height)} className="chart-population" />
        <polyline points={points(data, 'generation', maxGeneration, width, height)} className="chart-generation" />
        <text x="36" y="14" className="chart-label">ПОПУЛЯЦИЯ</text>
        <text x="144" y="14" className="chart-label secondary">ЁМКОСТЬ</text>
        <text x="236" y="14" className="chart-label accent">ПОКОЛЕНИЯ</text>
        <text x="36" y={height - 5} className="chart-tick">тик {data[0].tick}</text>
        <text x={width - 36} y={height - 5} textAnchor="end" className="chart-tick">тик {data.at(-1).tick}</text>
      </svg>
    </div>
  )
}
