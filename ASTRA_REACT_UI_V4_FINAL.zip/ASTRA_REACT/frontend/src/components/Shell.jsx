import React from 'react'

const nav = [
  ['dashboard', 'Обзор', '⌂'],
  ['constructor', 'Конструктор', '◇'],
  ['analytics', 'Аналитика', '⌁'],
  ['inspector', 'Сущность', '◎'],
  ['journal', 'Журнал', '≡'],
  ['help', 'Справка', '?'],
]

export default function Shell({ page, setPage, state, connected, onStart, onPause, onStep, onReset, onExport, children }) {
  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark">A</div>
          <div><b>ASTRA</b><span>PLANET A-17</span></div>
        </div>
        <div className="nav-label">ЛАБОРАТОРИЯ</div>
        <nav className="nav">
          {nav.map(([id, label, icon]) => (
            <button key={id} className={page === id ? 'active' : ''} onClick={() => setPage(id)}>
              <span className="nav-icon">{icon}</span>{label}
            </button>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <div className="connection"><i className={connected ? 'online-dot' : 'offline-dot'} /> {connected ? 'ДВИЖОК ОНЛАЙН' : 'НЕТ СОЕДИНЕНИЯ'}</div>
          <div className="sidebar-version">CORE V4 · REACT UI</div>
        </div>
      </aside>

      <main className="workspace">
        <header className="topbar">
          <div>
            <div className="eyebrow">ИНТЕРАКТИВНЫЙ СИМУЛЯТОР ЭКОСИСТЕМЫ</div>
            <h1>Планета A-17</h1>
          </div>
          <div className="top-actions">
            <div className={`run-state ${state?.running ? 'running' : ''}`}><i />{state?.running ? 'СИМУЛЯЦИЯ ИДЁТ' : 'ПАУЗА'}</div>
            <button className="icon-button" onClick={onExport} title="Экспорт JSON">↓</button>
            <button className="primary-button" onClick={state?.running ? onPause : onStart}>{state?.running ? 'Ⅱ Пауза' : '▶ Запуск'}</button>
          </div>
        </header>

        <div className="quick-toolbar">
          <span>ТИК <b>{state?.planet?.tick ?? 0}</b></span>
          <span>ПОПУЛЯЦИЯ <b>{state?.planet?.population ?? 0}/{state?.planet?.capacity ?? 0}</b></span>
          <span>ПОКОЛЕНИЕ <b>{state?.planet?.generation ?? 0}</b></span>
          <div className="toolbar-spacer" />
          <button onClick={onStep}>⏭ ШАГ</button>
          <button onClick={onReset}>⟳ СБРОС</button>
        </div>

        <div className="page-content">{children}</div>
      </main>
    </div>
  )
}
