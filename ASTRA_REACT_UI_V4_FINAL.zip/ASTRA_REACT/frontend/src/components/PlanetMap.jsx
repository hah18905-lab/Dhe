import React, { useMemo, useState } from 'react'

const biomeClass = {
  'ОАЗИС': 'oasis',
  'ПУСТЫНЯ': 'desert',
  'ЛЕДНИК': 'ice',
  'АНОМАЛИЯ': 'anomaly',
}

const actionClass = {
  'ИСКАТЬ РЕСУРСЫ': 'action-resource',
  'ИСКАТЬ ВОДУ': 'action-water',
  'УКРЫТЬСЯ': 'action-safe',
  'ИССЛЕДОВАТЬ': 'action-explore',
  'ОТДЫХАТЬ': 'action-rest',
  'ВОСПРОИЗВЕСТИСЬ': 'action-repro',
  'ОЖИДАНИЕ': 'action-idle',
}

function cellHeat(cell) {
  const danger = (cell.radiation + cell.damage * 0.5) / 100
  const resource = cell.resources / 100
  const water = cell.water / 100
  const glow = Math.round(20 + resource * 40 + water * 24)
  const dangerOpacity = Math.min(0.50, danger * 0.65)
  return { '--cell-glow': `${glow}px`, '--danger-alpha': dangerOpacity }
}

export default function PlanetMap({ cells, organisms, selectedId, onSelect, onCellClick, onHoverCell }) {
  const [hovered, setHovered] = useState(null)

  const byCell = useMemo(() => {
    const map = new Map()
    for (const organism of organisms) {
      const key = `${organism.x}:${organism.y}`
      if (!map.has(key)) map.set(key, [])
      map.get(key).push(organism)
    }
    return map
  }, [organisms])

  return (
    <div className="map-shell">
      <div className="map-topline">
        <span className="map-coords">X → &nbsp; Y ↓</span>
        <span className="map-hint">{hovered ? `(${hovered.x}, ${hovered.y}) · ${hovered.biome} · ресурсы ${hovered.resources}% · вода ${hovered.water}% · ☢ ${hovered.radiation}%` : 'Нажмите на организм, чтобы открыть его профиль'}</span>
      </div>
      <div className="planet-map" aria-label="Карта планеты A-17">
        {cells.map(cell => {
          const key = `${cell.x}:${cell.y}`
          const stack = byCell.get(key) || []
          return (
            <div key={key} className={`map-cell ${biomeClass[cell.biome]}`} style={cellHeat(cell)} title={`(${cell.x}, ${cell.y}) · ${cell.biome} · ресурсы ${cell.resources}% · вода ${cell.water}% · радиация ${cell.radiation}%`}>
              <div className="cell-overlay" />
              <span className="biome-code">{cell.biomeShort}</span>
              {stack.map((organism, index) => (
                <button
                  key={organism.id}
                  className={`organism-dot ${actionClass[organism.lastAction] || 'action-idle'} ${organism.id === selectedId ? 'selected' : ''}`}
                  style={{ left: `${34 + (index % 4) * 13}%`, top: `${35 + Math.floor(index / 4) * 13}%` }}
                  onClick={(e) => { e.stopPropagation(); onSelect(organism.id) }}
                  title={`Сущность #${organism.id}`}
                />
              ))}
              {stack.length > 1 && <span className="cell-count">{stack.length}</span>}
            </div>
          )
        })}
      </div>
      <div className="map-legend">
        <span><i className="legend-square oasis" /> Оазис</span>
        <span><i className="legend-square desert" /> Пустыня</span>
        <span><i className="legend-square ice" /> Ледник</span>
        <span><i className="legend-square anomaly" /> Аномалия</span>
        <span><i className="legend-dot" /> Организм</span>
        <span className="legend-note">Интенсивность свечения = доступность среды · красный оттенок = риск</span>
      </div>
    </div>
  )
}
