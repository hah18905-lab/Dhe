from __future__ import annotations

import json
import math
from pathlib import Path
from threading import RLock
from typing import Any

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

from engine import ACTIONS, BIOMES, BIOME_SHORT, Genome, Simulation, clamp, percent


APP_TITLE = "ASTRA — Planet A-17"


class SettingsPayload(BaseModel):
    temperature: float = Field(0.48, ge=0, le=1)
    water: float = Field(0.53, ge=0, le=1)
    resources: float = Field(0.62, ge=0, le=1)
    radiation: float = Field(0.28, ge=0, le=1)
    energy: float = Field(0.60, ge=0, le=1)
    stability: float = Field(0.72, ge=0, le=1)
    solar_activity: float = Field(0.30, ge=0, le=1)
    mutation_strength: float = Field(0.055, ge=0, le=0.20)
    initial_population: int = Field(80, ge=1, le=200)


class TickPayload(BaseModel):
    ticks: int = Field(1, ge=1, le=8)


class StormPayload(BaseModel):
    intensity: float | None = Field(None, ge=0, le=1)


class ClimatePayload(BaseModel):
    delta: float | None = Field(None, ge=-1, le=1)


class SelectPayload(BaseModel):
    organism_id: int


class SimulationService:
    def __init__(self) -> None:
        self.lock = RLock()
        self.settings = Simulation.default_settings()
        self.sim = Simulation(self.settings)
        self.running = False
        self.speed = 2

    def set_settings(self, raw: dict[str, Any], reset: bool) -> None:
        with self.lock:
            cleaned = dict(raw)
            cleaned["initial_population"] = int(cleaned["initial_population"])
            cleaned["mutation_strength"] = float(cleaned["mutation_strength"])
            self.settings = cleaned
            if reset:
                self.sim = Simulation(self.settings)
                self.running = False
            else:
                self.sim.settings = dict(self.settings)
                self.sim.mutation_strength = self.settings["mutation_strength"]
                self.sim.initial_population = self.settings["initial_population"]
                self.sim.planet.set_parameters(self.settings)
                self.sim._log("ПАРАМЕТРЫ ИЗМЕНЕНЫ ПОЛЬЗОВАТЕЛЕМ")

    def _safe_num(self, value: float) -> float:
        return 0.0 if not math.isfinite(value) else value

    def state(self) -> dict[str, Any]:
        with self.lock:
            sim = self.sim
            planet = sim.planet
            alive = [o for o in sim.population if o.alive]
            capacity = sim.carrying_capacity()
            last = sim.history[-1] if sim.history else None
            selected = sim.get_selected()

            cells = []
            for y, row in enumerate(planet.cells):
                for x, cell in enumerate(row):
                    cells.append({
                        "x": x,
                        "y": y,
                        "biome": cell.biome,
                        "biomeShort": BIOME_SHORT[cell.biome],
                        "resources": percent(cell.resources),
                        "water": percent(cell.water),
                        "radiation": percent(cell.radiation),
                        "temperature": percent(cell.temperature),
                        "damage": percent(cell.damage),
                    })

            organisms = []
            for o in alive:
                organisms.append({
                    "id": o.id,
                    "x": o.x,
                    "y": o.y,
                    "generation": o.generation,
                    "parentId": o.parent_id,
                    "age": o.age,
                    "energy": percent(o.energy),
                    "hydration": percent(o.hydration),
                    "health": percent(o.health),
                    "memory": percent(o.memory),
                    "lastAction": o.last_action,
                    "lastReward": round(o.last_reward, 4),
                    "children": o.children,
                    "totalActions": o.total_actions,
                    "successes": o.successes,
                    "cooldown": o.reproduction_cooldown,
                    "genome": {k: round(v, 4) for k, v in o.genome.values.items()},
                })

            decision = None
            if selected and selected.last_decision:
                ordered = sorted(selected.last_decision.scores.items(), key=lambda it: it[1], reverse=True)
                decision = {
                    "action": selected.last_decision.action,
                    "scores": [{"action": a, "score": round(s, 4)} for a, s in ordered],
                }

            quick = {
                "temperature": percent(planet.temperature),
                "water": percent(planet.water),
                "resources": percent(planet.resources),
                "radiation": percent(planet.radiation),
                "energy": percent(planet.energy),
                "stability": percent(planet.stability),
                "solarActivity": percent(planet.solar_activity),
                "population": len(alive),
                "births": sim.births,
                "deaths": sim.deaths,
                "capacity": capacity,
                "generation": sim.max_generation,
                "tick": sim.tick,
                "storm": round(planet.storm, 3),
                "event": planet.event or "",
            }

            environment_status = self.environment_status()
            metrics = {
                "power": round(last["power"], 4) if last else 0.0,
                "efficiency": round(last["efficiency"], 4) if last else 0.0,
                "entropy": round(last["entropy"], 4) if last else sim.entropy(),
                "latency": round(last["latency"], 4) if last else 0.0,
                "diversity": round(last["diversity"], 4) if last else sim.behavioral_diversity(),
            }

            snapshots = {
                "before": sim.before_snapshot,
                "after": sim.after_snapshot,
                "delta": self._snapshot_delta(sim.before_snapshot, sim.after_snapshot),
            }

            return {
                "app": APP_TITLE,
                "running": self.running,
                "speed": self.speed,
                "settings": dict(sim.settings),
                "actions": ACTIONS,
                "biomes": BIOMES,
                "planet": quick,
                "environmentStatus": environment_status,
                "cells": cells,
                "organisms": organisms,
                "selected": next((item for item in organisms if selected and item["id"] == selected.id), None),
                "decision": decision,
                "metrics": metrics,
                "history": sim.history[-240:],
                "journal": sim.journal[-120:],
                "snapshots": snapshots,
                "selectedId": sim.selected_id,
            }

    def environment_status(self) -> str:
        sim = self.sim
        p = sim.planet
        capacity = sim.carrying_capacity()
        pop = sum(o.alive for o in sim.population)
        ratio = pop / max(1, capacity)
        if p.radiation > 0.78 or p.water < 0.15 or p.resources < 0.15:
            return "КРИТИЧЕСКАЯ"
        if ratio > 0.95:
            return "ПЕРЕГРУЖЕНА"
        if p.radiation > 0.58 or p.water < 0.30 or p.resources < 0.30:
            return "НАПРЯЖЁННАЯ"
        if p.stability > 0.68 and p.water > 0.50 and p.resources > 0.50 and p.radiation < 0.35:
            return "БЛАГОПРИЯТНАЯ"
        return "СТАБИЛЬНАЯ"

    @staticmethod
    def _snapshot_delta(before: dict[str, Any] | None, after: dict[str, Any] | None) -> dict[str, Any] | None:
        if not before or not after:
            return None
        keys = ["population", "generation", "capacity", "avg_energy", "avg_health", "entropy"]
        return {key: round((after.get(key, 0) or 0) - (before.get(key, 0) or 0), 4) for key in keys}


service = SimulationService()

app = FastAPI(title=APP_TITLE, version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/api/health")
def health() -> dict[str, str]:
    return {"status": "ok", "project": "ASTRA"}


@app.get("/api/state")
def get_state() -> dict[str, Any]:
    return service.state()


@app.post("/api/sim/start")
def start() -> dict[str, Any]:
    with service.lock:
        service.running = True
    return service.state()


@app.post("/api/sim/pause")
def pause() -> dict[str, Any]:
    with service.lock:
        service.running = False
    return service.state()


@app.post("/api/sim/reset")
def reset() -> dict[str, Any]:
    with service.lock:
        service.sim = Simulation(service.settings)
        service.running = False
    return service.state()


@app.post("/api/sim/step")
def step(payload: TickPayload | None = None) -> dict[str, Any]:
    ticks = payload.ticks if payload else 1
    with service.lock:
        for _ in range(ticks):
            service.sim.step()
            if not any(o.alive for o in service.sim.population):
                service.running = False
                break
    return service.state()


@app.post("/api/sim/speed/{value}")
def set_speed(value: int) -> dict[str, Any]:
    if value < 1 or value > 10:
        raise HTTPException(status_code=400, detail="speed must be between 1 and 10")
    with service.lock:
        service.speed = value
    return service.state()


@app.post("/api/planet/apply")
def apply_planet(payload: SettingsPayload) -> dict[str, Any]:
    service.set_settings(payload.model_dump(), reset=False)
    return service.state()


@app.post("/api/planet/apply-reset")
def apply_reset(payload: SettingsPayload) -> dict[str, Any]:
    service.set_settings(payload.model_dump(), reset=True)
    return service.state()

@app.post("/api/planet/apply-start")
def apply_start(payload: SettingsPayload) -> dict[str, Any]:
    # Apply the edited environment as a new experiment and immediately start it.
    service.set_settings(payload.model_dump(), reset=True)
    with service.lock:
        service.running = True
    return service.state()


@app.post("/api/events/storm")
def storm(payload: StormPayload | None = None) -> dict[str, Any]:
    with service.lock:
        service.sim.planet.trigger_storm(payload.intensity if payload else None)
        service.sim._log(service.sim.planet.event)
    return service.state()


@app.post("/api/events/climate")
def climate(payload: ClimatePayload | None = None) -> dict[str, Any]:
    with service.lock:
        service.sim.planet.climate_shift(payload.delta if payload else None)
        service.sim._log(service.sim.planet.event)
    return service.state()


@app.post("/api/select")
def select(payload: SelectPayload) -> dict[str, Any]:
    with service.lock:
        alive_ids = {o.id for o in service.sim.population if o.alive}
        if payload.organism_id not in alive_ids:
            raise HTTPException(status_code=404, detail="organism not found")
        service.sim.selected_id = payload.organism_id
        selected = service.sim.get_selected()
        service.sim.last_decision = selected.last_decision if selected else None
    return service.state()


@app.get("/api/export")
def export_json() -> JSONResponse:
    with service.lock:
        sim = service.sim
        data = {
            "проект": "ASTRA V4",
            "объект": "Планета A-17",
            "тик": sim.tick,
            "настройки": sim.settings,
            "параметры_эволюции": {
                "сила_мутации": sim.mutation_strength,
                "начальная_популяция": sim.initial_population,
            },
            "планета": {
                "температура": sim.planet.temperature,
                "вода": sim.planet.water,
                "радиация": sim.planet.radiation,
                "ресурсы": sim.planet.resources,
                "энергия": sim.planet.energy,
                "стабильность": sim.planet.stability,
                "солнечная_активность": sim.planet.solar_activity,
            },
            "популяция": [
                {
                    "id": o.id,
                    "родитель": o.parent_id,
                    "поколение": o.generation,
                    "x": o.x,
                    "y": o.y,
                    "возраст": o.age,
                    "энергия": o.energy,
                    "вода": o.hydration,
                    "здоровье": o.health,
                    "память": o.memory,
                    "последнее_действие": o.last_action,
                    "потомков": o.children,
                    "жива": o.alive,
                    "геном": o.genome.values,
                }
                for o in sim.population
            ],
            "история": sim.history,
            "начальный_снимок": sim.before_snapshot,
            "финальный_снимок": sim.after_snapshot,
            "журнал": sim.journal,
        }
    return JSONResponse(content=data, headers={"Content-Disposition": 'attachment; filename="astra_A17_experiment.json"'})
