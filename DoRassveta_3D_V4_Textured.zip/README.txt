# Do Rassveta - 3D Version 4

Textured forest camp prototype for Raylib + CMake.

## Files
- main.cpp
- CMakeLists.txt
- assets/grass.png
- assets/dirt.png
- assets/wood.png
- assets/roof.png
- assets/water.png
- assets/tree.png
- assets/window.png
- assets/fire.png

## Build
Use the same Developer PowerShell / Visual Studio environment where Raylib already works:

Remove-Item -Recurse -Force build -ErrorAction SilentlyContinue

cmake -S . -B build -G "Visual Studio 17 2022" -A x64 -DCMAKE_TOOLCHAIN_FILE=C:/Users/Academy/vcpkg/scripts/buildsystems/vcpkg.cmake

cmake --build build --config Debug

Then run:
build/Debug/DoRassveta3D.exe

The CMake file copies the assets folder next to the executable automatically.

This version intentionally has normal bright lighting and no flashlight/darkness system.
