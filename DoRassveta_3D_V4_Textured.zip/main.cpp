#include "raylib.h"
#include <math.h>
#include <vector>
#include <algorithm>

// ============================================================
// DO RASSVETA - 3D VERSION 4
// Textured forest camp prototype
// No flashlight / no darkness system yet.
// ============================================================

struct TreeSpot
{
    Vector3 position;
    float scale;
};

struct RockSpot
{
    Vector3 position;
    float scale;
};

static float ClampFloat(float value, float minValue, float maxValue)
{
    if (value < minValue) return minValue;
    if (value > maxValue) return maxValue;
    return value;
}

static void DrawTexturedCube(Texture2D texture, Vector3 position,
                             float width, float height, float depth)
{
    DrawCubeTexture(texture, position, width, height, depth, WHITE);
}

static void DrawTree(Camera3D camera, Texture2D treeTexture, Vector3 position, float scale)
{
    // Camera-facing tree billboard. The texture itself contains the tree silhouette.
    DrawBillboardPro(
        camera, treeTexture,
        { 0.5f, 0.5f },
        position,
        { 0.0f, 0.0f },
        { 7.0f * scale, 10.0f * scale },
        { 0.0f, 0.0f },
        0.0f,
        WHITE
    );
}

static void DrawRock(Vector3 p, float s)
{
    DrawSphere({p.x, p.y + 0.35f * s, p.z}, 0.55f * s,
               Color{105,105,98,255});
}

static void DrawLog(Vector3 p, float radius, float length, Color color)
{
    DrawCylinder(p, radius, radius, length, 10, color);
}

int main()
{
    SetConfigFlags(FLAG_MSAA_4X_HINT | FLAG_VSYNC_HINT);

    InitWindow(1920, 1080, "Do Rassveta - 3D Version 4");
    SetTargetFPS(60);
    DisableCursor();

    // --------------------------------------------------------
    // Load textures
    // --------------------------------------------------------
    Texture2D grassTexture = LoadTexture("assets/grass.png");
    Texture2D dirtTexture  = LoadTexture("assets/dirt.png");
    Texture2D woodTexture  = LoadTexture("assets/wood.png");
    Texture2D roofTexture  = LoadTexture("assets/roof.png");
    Texture2D waterTexture = LoadTexture("assets/water.png");
    Texture2D treeTexture  = LoadTexture("assets/tree.png");
    Texture2D windowTexture = LoadTexture("assets/window.png");
    Texture2D fireTexture  = LoadTexture("assets/fire.png");

    // Models for textured planes.
    Model groundModel = LoadModelFromMesh(GenMeshPlane(100.0f, 100.0f, 1, 1));
    groundModel.materials[0].maps[MATERIAL_MAP_ALBEDO].texture = grassTexture;

    Model pathModel = LoadModelFromMesh(GenMeshPlane(5.5f, 38.0f, 1, 1));
    pathModel.materials[0].maps[MATERIAL_MAP_ALBEDO].texture = dirtTexture;

    Model waterModel = LoadModelFromMesh(GenMeshPlane(36.0f, 18.0f, 1, 1));
    waterModel.materials[0].maps[MATERIAL_MAP_ALBEDO].texture = waterTexture;

    // --------------------------------------------------------
    // Player
    // --------------------------------------------------------
    Vector3 playerPosition = { 0.0f, 1.75f, 14.0f };

    float yaw = 0.0f;
    float pitch = 0.0f;

    float targetYaw = yaw;
    float targetPitch = pitch;

    const float PLAYER_SPEED = 4.2f;
    const float MOUSE_SENSITIVITY = 0.0023f;

    Camera3D camera = { 0 };
    camera.position = playerPosition;
    camera.target = { 0.0f, 1.75f, 13.0f };
    camera.up = { 0.0f, 1.0f, 0.0f };
    camera.fovy = 72.0f;
    camera.projection = CAMERA_PERSPECTIVE;

    // --------------------------------------------------------
    // Forest
    // --------------------------------------------------------
    std::vector<TreeSpot> trees =
    {
        {{-10,0,  5},1.2f}, {{10,0,5},1.3f},
        {{-14,0, -5},1.5f}, {{14,0,-6},1.45f},
        {{-18,0,-14},1.7f}, {{18,0,-15},1.8f},
        {{-24,0,-20},1.9f}, {{24,0,-21},1.9f},
        {{-30,0,-8},2.1f},  {{30,0,-10},2.0f},
        {{-30,0,10},1.9f},  {{30,0,12},2.0f},
        {{-22,0,20},1.8f},  {{22,0,21},1.9f},
        {{-12,0,27},1.7f},  {{12,0,28},1.8f}
    };

    std::vector<RockSpot> rocks =
    {
        {{-7,0,  2},1.0f}, {{7,0,2},0.9f},
        {{-9,0,  7},0.8f}, {{9,0,7},1.0f},
        {{-6,0, -2},0.7f}, {{6,0,-2},0.8f}
    };

    // --------------------------------------------------------
    // Main loop
    // --------------------------------------------------------
    while (!WindowShouldClose())
    {
        float dt = GetFrameTime();
        dt = ClampFloat(dt, 0.0f, 0.033f);

        // Mouse look.
        Vector2 mouse = GetMouseDelta();
        targetYaw += mouse.x * MOUSE_SENSITIVITY;
        targetPitch -= mouse.y * MOUSE_SENSITIVITY;

        targetPitch = ClampFloat(targetPitch, -1.25f, 1.25f);

        // Smooth camera rotation.
        yaw += (targetYaw - yaw) * ClampFloat(dt * 18.0f, 0.0f, 1.0f);
        pitch += (targetPitch - pitch) * ClampFloat(dt * 18.0f, 0.0f, 1.0f);

        Vector3 forward =
        {
            sinf(yaw) * cosf(pitch),
            sinf(pitch),
            -cosf(yaw) * cosf(pitch)
        };

        Vector3 forwardFlat =
        {
            sinf(yaw),
            0.0f,
            -cosf(yaw)
        };

        Vector3 right =
        {
            cosf(yaw),
            0.0f,
            sinf(yaw)
        };

        Vector3 movement = {0,0,0};

        if (IsKeyDown(KEY_W))
        {
            movement.x += forwardFlat.x;
            movement.z += forwardFlat.z;
        }

        if (IsKeyDown(KEY_S))
        {
            movement.x -= forwardFlat.x;
            movement.z -= forwardFlat.z;
        }

        if (IsKeyDown(KEY_A))
        {
            movement.x -= right.x;
            movement.z -= right.z;
        }

        if (IsKeyDown(KEY_D))
        {
            movement.x += right.x;
            movement.z += right.z;
        }

        float moveLength = sqrtf(
            movement.x * movement.x +
            movement.z * movement.z
        );

        if (moveLength > 0.001f)
        {
            movement.x /= moveLength;
            movement.z /= moveLength;

            playerPosition.x += movement.x * PLAYER_SPEED * dt;
            playerPosition.z += movement.z * PLAYER_SPEED * dt;
        }

        // Keep the player inside the playable forest.
        playerPosition.x = ClampFloat(playerPosition.x, -42.0f, 42.0f);
        playerPosition.z = ClampFloat(playerPosition.z, -42.0f, 42.0f);
        playerPosition.y = 1.75f;

        camera.position = playerPosition;
        camera.target =
        {
            playerPosition.x + forward.x,
            playerPosition.y + forward.y,
            playerPosition.z + forward.z
        };

        BeginDrawing();

        // Daylight sky.
        ClearBackground(Color{150,170,180,255});

        BeginMode3D(camera);

        // ----------------------------------------------------
        // Ground / path / lake
        // ----------------------------------------------------
        DrawModel(groundModel, {0,0,0}, 1.0f, WHITE);
        DrawModel(pathModel, {0,0.02f,5}, 1.0f, WHITE);
        DrawModel(waterModel, {0,0.035f,-30}, 1.0f, WHITE);

        // ----------------------------------------------------
        // Cabin
        // ----------------------------------------------------
        Vector3 cabin = {0,0,-8};

        DrawTexturedCube(
            woodTexture,
            {cabin.x, 2.0f, cabin.z},
            8.0f, 4.0f, 6.0f
        );

        // Roof layers.
        DrawTexturedCube(
            roofTexture,
            {cabin.x, 4.45f, cabin.z},
            9.5f, 0.8f, 7.2f
        );

        DrawTexturedCube(
            roofTexture,
            {cabin.x, 4.95f, cabin.z},
            8.6f, 0.35f, 6.6f
        );

        // Porch.
        DrawTexturedCube(
            woodTexture,
            {cabin.x,0.45f,cabin.z-3.75f},
            5.8f,0.35f,2.0f
        );

        DrawTexturedCube(
            woodTexture,
            {cabin.x,0.20f,cabin.z-4.55f},
            5.0f,0.25f,0.8f
        );

        // Door.
        DrawTexturedCube(
            woodTexture,
            {cabin.x,1.75f,cabin.z-3.12f},
            1.45f,3.0f,0.18f
        );

        DrawSphere(
            {cabin.x+0.42f,1.75f,cabin.z-3.25f},
            0.08f,
            GOLD
        );

        // Windows.
        DrawCubeTexture(
            windowTexture,
            {cabin.x-2.5f,2.2f,cabin.z-3.16f},
            1.55f,1.45f,0.10f,
            WHITE
        );

        DrawCubeTexture(
            windowTexture,
            {cabin.x+2.5f,2.2f,cabin.z-3.16f},
            1.55f,1.45f,0.10f,
            WHITE
        );

        // ----------------------------------------------------
        // Fire
        // ----------------------------------------------------
        Vector3 firePos = {0,0,3};

        for (int i=0;i<10;i++)
        {
            float a = ((float)i/10.0f)*PI*2.0f;
            DrawSphere(
                {
                    firePos.x + cosf(a)*1.15f,
                    0.22f,
                    firePos.z + sinf(a)*1.15f
                },
                0.30f,
                Color{100,100,94,255}
            );
        }

        DrawCube(
            {firePos.x,0.38f,firePos.z},
            1.8f,0.28f,0.28f,
            Color{57,34,20,255}
        );

        DrawCube(
            {firePos.x,0.58f,firePos.z},
            0.28f,0.28f,1.8f,
            Color{57,34,20,255}
        );

        // Billboard flame.
        DrawBillboardPro(
            camera,
            fireTexture,
            {0.5f,0.5f},
            {firePos.x,1.55f,firePos.z},
            {0,0},
            {2.2f,2.8f},
            {0,0},
            0.0f,
            WHITE
        );

        // ----------------------------------------------------
        // Objects around camp
        // ----------------------------------------------------
        DrawTexturedCube(
            woodTexture,
            {-4.0f,0.5f,-0.5f},
            1.4f,0.9f,1.1f
        );

        DrawTexturedCube(
            woodTexture,
            {-4.5f,1.25f,-0.5f},
            1.1f,0.7f,0.9f
        );

        // Logs.
        DrawLog({4.0f,0.35f,-0.5f},0.22f,1.8f,
                Color{82,48,25,255});
        DrawLog({4.0f,0.70f,-0.5f},0.22f,1.8f,
                Color{98,57,28,255});

        // Stumps.
        DrawCylinder({-3,0.35f,2.5f},0.55f,0.65f,0.7f,10,
                     Color{82,48,25,255});
        DrawCylinder({3.5f,0.35f,2.3f},0.55f,0.65f,0.7f,10,
                     Color{82,48,25,255});

        // Rocks.
        for (const RockSpot& r : rocks)
            DrawRock(r.position,r.scale);

        // Trees.
        for (const TreeSpot& t : trees)
            DrawTree(camera,treeTexture,t.position,t.scale);

        EndMode3D();

        // ----------------------------------------------------
        // HUD
        // ----------------------------------------------------
        DrawRectangle(0,0,1920,70,Fade(BLACK,0.20f));

        DrawText(
            "DO RASSVETA",
            30,20,30,WHITE
        );

        DrawText(
            "FOREST CAMP",
            280,25,20,WHITE
        );

        DrawRectangle(
            20,930,320,110,
            Fade(BLACK,0.45f)
        );

        DrawText(
            "WASD - MOVE",
            40,945,20,WHITE
        );

        DrawText(
            "MOUSE - LOOK",
            40,975,20,WHITE
        );

        DrawText(
            "ESC - EXIT",
            40,1005,20,LIGHTGRAY
        );

        EndDrawing();
    }

    // --------------------------------------------------------
    // Cleanup
    // --------------------------------------------------------
    UnloadModel(groundModel);
    UnloadModel(pathModel);
    UnloadModel(waterModel);

    UnloadTexture(grassTexture);
    UnloadTexture(dirtTexture);
    UnloadTexture(woodTexture);
    UnloadTexture(roofTexture);
    UnloadTexture(waterTexture);
    UnloadTexture(treeTexture);
    UnloadTexture(windowTexture);
    UnloadTexture(fireTexture);

    EnableCursor();
    CloseWindow();

    return 0;
}
