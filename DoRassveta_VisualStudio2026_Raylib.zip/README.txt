DO RASSVETA — Raylib edition

The project was converted from SFML 3 to raylib.

Requirements:
- Visual Studio with Desktop development with C++
- CMake
- vcpkg installed at C:/vcpkg

If raylib is not installed:
C:/vcpkg/vcpkg.exe install raylib:x64-windows

Then open this folder in Visual Studio and configure/build the CMake preset:
vs-vcpkg / Debug

Controls:
WASD — move
Mouse — look
F — flashlight
Space — flashlight battery drain
H — print rules
Esc — exit
