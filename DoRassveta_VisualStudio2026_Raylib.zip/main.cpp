#include "raylib.h"
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <iostream>
#include <string>
#include <vector>

static constexpr int SW=960, SH=540, MAP_W=24, MAP_H=24;
const std::vector<std::string> MAP={
"########################","#..........#...........#","#..........#...........#",
"#..........#...........#","#....######...........##","#....#................#",
"#....#................#","#....#.....####.......#","#..........#..........#",
"#..........#..........#","###........#..........#","#.....................#",
"#.....................#","#.........####........#","#.........#..#........#",
"#.........#..#........#","#.....................#","#....###########......#",
"#.....................#","#.....................#","#..........#..........#",
"#..........#..........#","#.....................#","########################"};

struct Player { double x=3.5,y=3.5,a=0; int hp=100,fear=0,battery=100; bool flashlight=true,fire=true; };
struct Monster { double x=14.5,y=10.5,speed=.72; bool alive=true; };
Player p; Monster m; Texture2D wallTex{},monsterTex{};
double gameMinutes=22*60,eventTimer=0,fireTimer=0; bool gameOver=false;
std::string message="SURVIVE UNTIL 06:00. PRESS H FOR RULES.";

double normAngle(double a){while(a>PI)a-=2*PI;while(a<-PI)a+=2*PI;return a;}
bool solid(double x,double y){int mx=(int)x,my=(int)y;return mx<0||my<0||mx>=MAP_W||my>=MAP_H||MAP[my][mx]=='#';}
void movePlayer(double dx,double dy){double nx=p.x+dx,ny=p.y+dy;if(!solid(nx,p.y))p.x=nx;if(!solid(p.x,ny))p.y=ny;}
void addFear(int v){p.fear=std::clamp(p.fear+v,0,100);if(p.fear>=100){gameOver=true;message="YOU LOST YOUR MIND.";}}
void damage(int v){p.hp-=v;if(p.hp<=0){p.hp=0;gameOver=true;message="THE FOREST TOOK YOU.";}}
std::string clockText(){int mins=(int)gameMinutes,h=(mins/60)%24,mm=mins%60;char b[16];std::snprintf(b,sizeof(b),"%02d:%02d",h,mm);return b;}

const std::vector<std::pair<char,std::vector<std::string>>> FONT={
{'A',{"01110","10001","10001","11111","10001","10001","10001"}},{'B',{"11110","10001","10001","11110","10001","10001","11110"}},
{'C',{"01111","10000","10000","10000","10000","10000","01111"}},{'D',{"11110","10001","10001","10001","10001","10001","11110"}},
{'E',{"11111","10000","10000","11110","10000","10000","11111"}},{'F',{"11111","10000","10000","11110","10000","10000","10000"}},
{'G',{"01111","10000","10000","10111","10001","10001","01111"}},{'H',{"10001","10001","10001","11111","10001","10001","10001"}},
{'I',{"11111","00100","00100","00100","00100","00100","11111"}},{'J',{"00111","00010","00010","00010","10010","10010","01100"}},
{'K',{"10001","10010","10100","11000","10100","10010","10001"}},{'L',{"10000","10000","10000","10000","10000","10000","11111"}},
{'M',{"10001","11011","10101","10101","10001","10001","10001"}},{'N',{"10001","11001","10101","10011","10001","10001","10001"}},
{'O',{"01110","10001","10001","10001","10001","10001","01110"}},{'P',{"11110","10001","10001","11110","10000","10000","10000"}},
{'R',{"11110","10001","10001","11110","10100","10010","10001"}},{'S',{"01111","10000","10000","01110","00001","00001","11110"}},
{'T',{"11111","00100","00100","00100","00100","00100","00100"}},{'U',{"10001","10001","10001","10001","10001","10001","01110"}},
{'V',{"10001","10001","10001","10001","10001","01010","00100"}},{'W',{"10001","10001","10001","10101","10101","11011","10001"}},
{'Y',{"10001","10001","01010","00100","00100","00100","00100"}},{'0',{"01110","10001","10011","10101","11001","10001","01110"}},
{'1',{"00100","01100","00100","00100","00100","00100","01110"}},{'2',{"01110","10001","00001","00010","00100","01000","11111"}},
{'3',{"11110","00001","00001","01110","00001","00001","11110"}},{'4',{"00010","00110","01010","10010","11111","00010","00010"}},
{'5',{"11111","10000","10000","11110","00001","00001","11110"}},{'6',{"01110","10000","10000","11110","10001","10001","01110"}},
{'7',{"11111","00001","00010","00100","01000","01000","01000"}},{'8',{"01110","10001","10001","01110","10001","10001","01110"}},
{'9',{"01110","10001","10001","01111","00001","00001","01110"}},{':',{"00000","00100","00100","00000","00100","00100","00000"}},
{'%',{"11001","11010","00100","01000","10110","10011","00000"}},{' ',{"00000","00000","00000","00000","00000","00000","00000"}},
{'.',{"00000","00000","00000","00000","00000","01100","01100"}}};

void text(const std::string&s,int x,int y,int scale=3){
 for(char c:s){c=(char)std::toupper((unsigned char)c);
  auto it=std::find_if(FONT.begin(),FONT.end(),[&](const auto&q){return q.first==c;});
  if(it!=FONT.end())for(int yy=0;yy<7;yy++)for(int xx=0;xx<5;xx++)if(it->second[yy][xx]=='1')DrawRectangle(x+xx*scale,y+yy*scale,scale,scale,WHITE);
  x+=6*scale;
 }
}

void renderWorld(){
 DrawRectangle(0,0,SW,SH/2,Color{12,19,25,255});DrawRectangle(0,SH/2,SW,SH/2,Color{34,38,28,255});
 std::vector<double> zbuf(SW);
 for(int x=0;x<SW;x++){
  double cam=2.0*x/SW-1,rayA=p.a+cam*(PI/3)/2,rx=cos(rayA),ry=sin(rayA);
  int mx=(int)p.x,my=(int)p.y;double dx=rx==0?1e30:abs(1/rx),dy=ry==0?1e30:abs(1/ry);
  int sx=rx<0?-1:1,sy=ry<0?-1:1;double sideX=rx<0?(p.x-mx)*dx:(mx+1-p.x)*dx,sideY=ry<0?(p.y-my)*dy:(my+1-p.y)*dy;
  int side=0;bool hit=false;
  for(int i=0;i<64&&!hit;i++){if(sideX<sideY){sideX+=dx;mx+=sx;side=0;}else{sideY+=dy;my+=sy;side=1;}if(mx<0||my<0||mx>=MAP_W||my>=MAP_H){hit=true;break;}if(MAP[my][mx]=='#')hit=true;}
  double dist=(side==0?sideX-dx:sideY-dy)*cos(rayA-p.a);dist=max(.05,dist);zbuf[x]=dist;
  int line=(int)(SH/dist),start=max(0,SH/2-line/2),end=min(SH-1,SH/2+line/2);
  int tx=(int)(wallTex.width*(side==0?(p.y+dist*ry):(p.x+dist*rx)))%(int)wallTex.width;if(tx<0)tx+=wallTex.width;
  Rectangle source{(float)tx,0,1,(float)wallTex.height},dest{(float)x,(float)start,1,(float)(end-start+1)};
  Color tint=dist>8?Color{55,55,55,255}:Color{180,180,180,255};if(side==1)tint=Color{(unsigned char)(tint.r*.75f),(unsigned char)(tint.g*.75f),(unsigned char)(tint.b*.75f),255};
  DrawTexturePro(wallTex,source,dest,{0,0},0,tint);
 }
 double dx=m.x-p.x,dy=m.y-p.y,dist=sqrt(dx*dx+dy*dy),ang=normAngle(atan2(dy,dx)-p.a);
 if(abs(ang)<PI/3&&dist>.3){int sx=(int)(SW/2+tan(ang)*SW*.82),h=(int)(SH/dist*.75),w=h*2/3,left=sx-w/2,top=SH/2-h/2,frame=(int)(gameMinutes*2)%4;
  Rectangle source{(float)(frame*96),0,96,144},dest{(float)left,(float)top,(float)w,(float)h};Color tint=dist>7?Color{70,70,70,255}:Color{220,220,220,255};if(!p.flashlight||p.battery<=0)tint=Color{75,75,75,255};
  if(left+w>0&&left<SW&&dist<zbuf[clamp(sx,0,SW-1)]+1)DrawTexturePro(monsterTex,source,dest,{0,0},0,tint);
 }
 if(p.flashlight&&p.battery>0)DrawCircle(SW/2,SH/2,260,Color{255,255,210,18});
 DrawRectangle(0,SH-76,SW,76,Color{5,7,7,225});
 text("HP "+to_string(p.hp),18,SH-66,3);text("FEAR "+to_string(p.fear)+"%",170,SH-66,3);text("BAT "+to_string(p.battery)+"%",390,SH-66,3);text("TIME "+clockText(),600,SH-66,3);text(p.fire?"FIRE OK":"FIRE OUT",800,SH-66,2);
 text("WASD MOVE  MOUSE LOOK  F FLASHLIGHT  H RULES  ESC QUIT",18,SH-25,2);
}
void eventTick(){if(eventTimer>0)return;int r=rand()%100;eventTimer=6;if(r<18){addFear(4);message="A BRANCH SNAPS BEHIND YOU.";}else if(r<32){addFear(8);message="SOMEONE WHISPERS YOUR NAME.";}else if(r<42)message="THREE KNOCKS. SOMEWHERE NEARBY.";else if(r<52){addFear(6);message="A LIGHT MOVES BETWEEN THE TREES.";}else if(r<62){message="YOU HEAR SLOW BREATHING.";m.speed=.85;}else message="THE FOREST IS SILENT.";}
void updateMonster(double dt){if(!m.alive)return;double dx=p.x-m.x,dy=p.y-m.y,dist=sqrt(dx*dx+dy*dy);if(dist<9){double vx=dx/dist,vy=dy/dist,speed=m.speed*(p.fire?.45:1),nx=m.x+vx*speed*dt,ny=m.y+vy*speed*dt;if(!solid(nx,m.y))m.x=nx;if(!solid(m.x,ny))m.y=ny;if(dist<.85){damage(15);addFear(12);m.x-=vx*1.2;m.y-=vy*1.2;message="THE THING ATTACKED YOU.";}}}

int main(){
 srand((unsigned)time(nullptr));InitWindow(SW,SH,"DO RASSVETA - 2D RAYCAST HORROR");SetTargetFPS(60);DisableCursor();SetMousePosition(SW/2,SH/2);
 wallTex=LoadTexture("assets/wall.png");monsterTex=LoadTexture("assets/monster.png");
 if(!IsTextureReady(wallTex)||!IsTextureReady(monsterTex)){cerr<<"Could not load assets. Run the executable from the project folder.\n";if(IsTextureReady(wallTex))UnloadTexture(wallTex);if(IsTextureReady(monsterTex))UnloadTexture(monsterTex);CloseWindow();return 1;}
 while(!WindowShouldClose()){
  double dt=min((double)GetFrameTime(),.05);
  if(IsKeyPressed(KEY_F))p.flashlight=!p.flashlight;
  if(IsKeyPressed(KEY_H)){cout<<"\nRULES:\n1. Do not enter deep forest after midnight.\n2. Never answer your name.\n3. Do not approach a person on the clearing.\n4. Do not follow lights.\n5. Do not look into the house windows after midnight.\n6. Never open a door after three knocks.\n7. At 03:00 make sure the fire still burns.\n\n";message="RULES PRINTED TO CONSOLE.";}
  if(!gameOver){
   Vector2 mp=GetMousePosition();p.a+=(mp.x-SW/2)*.0027;SetMousePosition(SW/2,SH/2);
   double speed=2*dt*(IsKeyDown(KEY_LEFT_SHIFT)?1.55:1),fx=cos(p.a),fy=sin(p.a),rx=-fy,ry=fx;
   if(IsKeyDown(KEY_W))movePlayer(fx*speed,fy*speed);if(IsKeyDown(KEY_S))movePlayer(-fx*speed,-fy*speed);if(IsKeyDown(KEY_A))movePlayer(-rx*speed,-ry*speed);if(IsKeyDown(KEY_D))movePlayer(rx*speed,ry*speed);
   gameMinutes+=dt*3;eventTimer-=dt;eventTick();updateMonster(dt);
   if(p.flashlight&&p.battery>0&&IsKeyDown(KEY_SPACE))p.battery=max(0,p.battery-(int)(dt*5));
   if(gameMinutes>=360){gameOver=true;message=(p.fire&&p.fear<80)?"SUNRISE. YOU SURVIVED.":"SUNRISE. BUT SOMETHING FOLLOWED YOU.";}
   if(gameMinutes>=180){fireTimer+=dt;if(fireTimer>25&&p.fire){p.fire=false;message="THE CAMPFIRE HAS GONE OUT.";}}
  }
  BeginDrawing();ClearBackground(BLACK);renderWorld();
  if(!message.empty()){DrawRectangle(130,18,700,42,Color{0,0,0,170});text(message,145,30,2);}
  if(gameOver){DrawRectangle(0,0,SW,SH,Color{0,0,0,170});text(gameMinutes>=360?"06:00":"GAME OVER",SW/2-70,SH/2-25,5);text("PRESS ESC TO EXIT",SW/2-120,SH/2+25,3);}
  EndDrawing();
 }
 UnloadTexture(wallTex);UnloadTexture(monsterTex);CloseWindow();return 0;
}
