@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul
cd /d "%~dp0"

title ASTRA - ЗАПУСК

echo.
echo ================================================
echo              ASTRA — БЫСТРЫЙ ЗАПУСК
echo ================================================
echo.

REM -------------------- Python --------------------
set "PY="
where py >nul 2>nul
if not errorlevel 1 set "PY=py -3"
if not defined PY (
    where python >nul 2>nul
    if not errorlevel 1 set "PY=python"
)
if not defined PY (
    echo [ОШИБКА] Python не найден.
    echo Установите Python 3.11+ и добавьте его в PATH.
    pause
    exit /b 1
)
echo [ГОТОВО] Python: %PY%

REM -------------------- Node.js --------------------
where npm >nul 2>nul
if errorlevel 1 (
    echo [ОШИБКА] Node.js / npm не найден.
    echo Установите Node.js LTS и запустите программу снова.
    pause
    exit /b 1
)
echo [ГОТОВО] Node.js / npm найден.

REM -------------------- Окружение Python --------------------
echo.
echo [1/5] Подготовка окружения Python...
if not exist "backend\.venv\Scripts\python.exe" (
    %PY% -m venv "backend\.venv"
)
if exist "backend\.venv\Scripts\python.exe" (
    set "ASTRA_PY=%~dp0backend\.venv\Scripts\python.exe"
    echo [ГОТОВО] Окружение Python готово.
) else (
    set "ASTRA_PY=%PY%"
    echo [ВНИМАНИЕ] Виртуальное окружение недоступно. Используется установленный Python.
)

%ASTRA_PY% -m pip --version >nul 2>nul
if errorlevel 1 (
    echo [ИНФО] pip отсутствует. Включаем pip...
    %ASTRA_PY% -m ensurepip --upgrade
)

REM -------------------- Зависимости ядра --------------------
echo.
echo [2/5] Проверка зависимостей симуляционного ядра...
%ASTRA_PY% -m pip install -r "backend\requirements.txt"
if errorlevel 1 (
    echo [ОШИБКА] Не удалось установить зависимости симуляционного ядра.
    pause
    exit /b 1
)

REM -------------------- Зависимости интерфейса --------------------
echo.
echo [3/5] Проверка зависимостей интерфейса...
if not exist "frontend\node_modules" (
    pushd "frontend"
    call npm install
    set "NPM_EXIT=!errorlevel!"
    popd
    if not "!NPM_EXIT!"=="0" (
        echo [ОШИБКА] Не удалось установить зависимости интерфейса.
        pause
        exit /b 1
    )
) else (
    echo [ГОТОВО] Зависимости интерфейса уже установлены.
)

REM -------------------- Запуск ядра --------------------
echo.
echo [4/5] Запуск симуляционного ядра...
start "ASTRA — Ядро" cmd /k "cd /d ""%~dp0backend"" && ""%ASTRA_PY%"" -m uvicorn api:app --host 127.0.0.1 --port 8000"

echo Ожидание готовности симуляционного ядра...
set "READY="
for /L %%I in (1,1,30) do (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "try { $r=Invoke-WebRequest -UseBasicParsing -TimeoutSec 1 http://127.0.0.1:8000/api/health; if ($r.StatusCode -eq 200) { exit 0 } } catch {}; exit 1" >nul 2>nul
    if not errorlevel 1 (
        set "READY=1"
        goto :backend_ready
    )
    timeout /t 1 /nobreak >nul
)

if not defined READY (
    echo.
    echo [ОШИБКА] Симуляционное ядро не запустилось вовремя.
    echo Проверьте окно «ASTRA — Ядро» для просмотра ошибки Python.
    pause
    exit /b 1
)

:backend_ready
echo [ГОТОВО] Симуляционное ядро доступно: http://127.0.0.1:8000

REM -------------------- Запуск интерфейса --------------------
echo.
echo [5/5] Запуск интерфейса ASTRA...
start "ASTRA — Интерфейс" cmd /k "cd /d ""%~dp0frontend"" && npm run dev -- --host 127.0.0.1 --port 5173"

echo Ожидание готовности интерфейса...
for /L %%I in (1,1,20) do (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "try { $r=Invoke-WebRequest -UseBasicParsing -TimeoutSec 1 http://127.0.0.1:5173; if ($r.StatusCode -ge 200 -and $r.StatusCode -lt 500) { exit 0 } } catch {}; exit 1" >nul 2>nul
    if not errorlevel 1 goto :frontend_ready
    timeout /t 1 /nobreak >nul
)

echo [ВНИМАНИЕ] Интерфейс ещё не ответил. Через несколько секунд его можно открыть вручную.
:frontend_ready
start "" "http://127.0.0.1:5173"

echo.
echo ================================================
echo              ASTRA ГОТОВА К РАБОТЕ
echo ================================================
echo.
echo Интерфейс: http://127.0.0.1:5173
echo Ядро:       http://127.0.0.1:8000/docs
echo.
echo Не закрывайте оба окна ASTRA во время работы.
echo.
pause
