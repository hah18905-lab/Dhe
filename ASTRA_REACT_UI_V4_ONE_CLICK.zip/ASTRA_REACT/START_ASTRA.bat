@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"

echo.
echo ==========================================
echo        ASTRA - ONE CLICK START
echo ==========================================
echo.

where python >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Python not found.
    echo Install Python 3.11+ and make sure it is added to PATH.
    pause
    exit /b 1
)

where npm >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Node.js/npm not found.
    echo Install Node.js LTS and reopen this file.
    pause
    exit /b 1
)

if not exist "backend\.venv\Scripts\python.exe" (
    echo [1/4] Creating Python virtual environment...
    python -m venv "backend\.venv"
    if errorlevel 1 (
        echo [ERROR] Failed to create Python virtual environment.
        pause
        exit /b 1
    )
)

if not exist "backend\.venv\.astra_deps_installed" (
    echo [2/4] Installing Python dependencies...
    "backend\.venv\Scripts\python.exe" -m pip install -r "backend\requirements.txt"
    if errorlevel 1 (
        echo [ERROR] Python dependency installation failed.
        pause
        exit /b 1
    )
    type nul > "backend\.venv\.astra_deps_installed"
) else (
    echo [2/4] Python dependencies: OK
)

if not exist "frontend\node_modules" (
    echo [3/4] Installing React dependencies...
    cd /d "%~dp0frontend"
    call npm install
    if errorlevel 1 (
        echo [ERROR] React dependency installation failed.
        pause
        exit /b 1
    )
    cd /d "%~dp0"
) else (
    echo [3/4] React dependencies: OK
)

echo [4/4] Starting ASTRA...
start "ASTRA Backend" cmd /k "cd /d "%~dp0backend" && .venv\Scripts\python.exe -m uvicorn api:app --host 127.0.0.1 --port 8000"
start "ASTRA Frontend" cmd /k "cd /d "%~dp0frontend" && npm run dev"

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$ok=$false; for($i=0;$i -lt 45;$i++){ try { if((Test-NetConnection 127.0.0.1 -Port 5173 -WarningAction SilentlyContinue).TcpTestSucceeded){$ok=$true;break} } catch {} Start-Sleep -Seconds 1 }; if($ok){Start-Process 'http://127.0.0.1:5173'} else {Start-Process 'http://127.0.0.1:5173'}"

echo.
echo ASTRA is starting.
echo Browser: http://127.0.0.1:5173
 echo.
echo Do not close the two ASTRA terminal windows while using the application.
pause
