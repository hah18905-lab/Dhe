@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ==================================================
echo         ASTRA — ДИАГНОСТИКА ЗАПУСКА
echo ==================================================
echo.
where python >nul 2>nul && echo [OK] python найден || echo [X] python НЕ найден
where py >nul 2>nul && echo [OK] py найден || echo [X] py НЕ найден
where node >nul 2>nul && echo [OK] node найден || echo [X] node НЕ найден
where npm >nul 2>nul && echo [OK] npm найден || echo [X] npm НЕ найден
if exist "frontend\package.json" (echo [OK] frontend\package.json найден) else (echo [X] frontend\package.json НЕ найден)
if exist "backend\api.py" (echo [OK] backend\api.py найден) else (echo [X] backend\api.py НЕ найден)
if exist "frontend\src\App.jsx" (echo [OK] frontend\src\App.jsx найден) else (echo [X] frontend\src\App.jsx НЕ найден)
echo.
pause
