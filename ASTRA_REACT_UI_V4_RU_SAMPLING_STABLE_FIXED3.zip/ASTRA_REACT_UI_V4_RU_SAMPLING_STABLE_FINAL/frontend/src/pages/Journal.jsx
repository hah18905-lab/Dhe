import React from 'react'
import { Section, StatusPill } from '../components/Ui'

export default function Journal({ state }) {
  return (
    <div className="page-grid">
      <div className="hero-row"><div><div className="page-kicker">ЖУРНАЛ · ПОТОК СОБЫТИЙ</div><h2 className="page-title">Хронология эксперимента</h2><p className="page-description">Рождения, смерти, контрольные точки, космические воздействия и изменения климата.</p></div><StatusPill>{state.journal.length} событий</StatusPill></div>
      <Section title="События" subtitle="Последние записи">
        <div className="journal-stream">{[...state.journal].reverse().map((line, i) => <div key={`${line}-${i}`} className="journal-row"><span className="journal-index">{String(i+1).padStart(3,'0')}</span><code>{line}</code></div>)}</div>
      </Section>
    </div>
  )
}
