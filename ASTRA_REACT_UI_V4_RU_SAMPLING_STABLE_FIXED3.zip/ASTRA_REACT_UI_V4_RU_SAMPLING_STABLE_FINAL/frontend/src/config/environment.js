export const environmentFields = [
  ['temperature', 'Температура', 'термическая нагрузка среды'],
  ['water', 'Вода', 'доступность воды'],
  ['resources', 'Ресурсы', 'доступность ресурсов'],
  ['radiation', 'Радиация', 'экологический риск'],
  ['energy', 'Доступная энергия', 'энергетический потенциал'],
  ['stability', 'Стабильность', 'устойчивость среды'],
  ['solar_activity', 'Солнечная активность', 'частота и сила космических воздействий'],
]

export const environmentPresets = {
  'Благоприятная': {
    temperature: 0.45, water: 0.78, resources: 0.82, radiation: 0.16,
    energy: 0.78, stability: 0.88, solar_activity: 0.18,
  },
  'Нормальная': {
    temperature: 0.48, water: 0.53, resources: 0.62, radiation: 0.28,
    energy: 0.60, stability: 0.72, solar_activity: 0.30,
  },
  'Засушливая': {
    temperature: 0.72, water: 0.24, resources: 0.46, radiation: 0.48,
    energy: 0.52, stability: 0.48, solar_activity: 0.45,
  },
  'Экстремальная': {
    temperature: 0.90, water: 0.10, resources: 0.18, radiation: 0.84,
    energy: 0.34, stability: 0.22, solar_activity: 0.82,
  },
}

export const presetDescriptions = {
  'Благоприятная': 'много воды и ресурсов',
  'Нормальная': 'базовый эксперимент',
  'Засушливая': 'ограниченная среда',
  'Экстремальная': 'высокий риск вымирания',
}

export function toApiSettings(settings) {
  return {
    ...settings,
    temperature: Number(settings.temperature),
    water: Number(settings.water),
    resources: Number(settings.resources),
    radiation: Number(settings.radiation),
    energy: Number(settings.energy),
    stability: Number(settings.stability),
    solar_activity: Number(settings.solar_activity),
    mutation_strength: Number(settings.mutation_strength),
    initial_population: Math.max(1, Math.round(Number(settings.initial_population))),
    seed: Math.max(0, Math.round(Number(settings.seed ?? 0))),
  }
}
