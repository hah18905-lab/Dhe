import React, { useCallback, useEffect, useRef, useState } from 'react'
import Shell from './components/Shell'
import Dashboard from './pages/Dashboard'
import Constructor from './pages/Constructor'
import Analytics from './pages/Analytics'
import Inspector from './pages/Inspector'
import Journal from './pages/Journal'
import Help from './pages/Help'
import Sampling from './pages/Sampling'
import { api } from './api'

const pageTitles = {
  dashboard: 'Обзор', constructor: 'Конструктор', analytics: 'Аналитика', sampling: 'Выборка', inspector: 'Сущность', journal: 'Журнал', help: 'Справка'
}

export default function App() {
  const [page, setPage] = useState('dashboard')
  const [state, setState] = useState(null)
  const [error, setError] = useState('')
  const [seriesResult, setSeriesResult] = useState(null)
  const [seriesBusy, setSeriesBusy] = useState(false)
  const busy = useRef(false)

  const refresh = useCallback(async () => {
    try {
      const next = await api.state()
      setState(next)
      if (next.series) setSeriesResult(next.series)
      setError('')
    } catch (e) {
      setError(e.message || 'Нет соединения с движком')
    }
  }, [])

  useEffect(() => { refresh() }, [refresh])

  useEffect(() => {
    if (!state?.running) return undefined
    const timer = setInterval(async () => {
      if (busy.current || document.hidden) return
      busy.current = true
      try {
        const ticksPerUpdate = Math.max(1, Math.min(8, Number(state.speed) || 1))
        const next = await api.step(ticksPerUpdate)
        setState(next)
        setError('')
      } catch (e) {
        setError(e.message || 'Ошибка шага')
      } finally {
        busy.current = false
      }
    }, 120)
    return () => clearInterval(timer)
  }, [state?.running, state?.speed])

  const command = async (fn) => {
    try {
      const next = await fn()
      setState(next)
      if (next.series) setSeriesResult(next.series)
      setError('')
    } catch (e) {
      setError(e.message || 'Команда не выполнена')
    }
  }

  const runSeries = async payload => {
    setSeriesBusy(true)
    try {
      const result = await api.runSeries(payload)
      setSeriesResult(result)
      setError('')
    } catch (e) {
      setError(e.message || 'Не удалось выполнить выборку')
      throw e
    } finally {
      setSeriesBusy(false)
    }
  }

  if (!state) {
    return <div className="loading-screen"><div className="loading-logo">A</div><h1>ASTRA</h1><p>Подключение к симуляционному ядру…</p>{error && <div className="startup-error">{error}<button onClick={refresh}>Повторить</button></div>}</div>
  }

  let content
  if (page === 'dashboard') content = <Dashboard
    state={state}
    onSelect={id => { setPage('inspector'); return command(() => api.select(id)) }}
    onStorm={i => command(() => api.storm(i ?? null))}
    onClimate={d => command(() => api.climate(d ?? null))}
    onStep={() => command(() => api.step(1))}
    onReset={() => command(() => api.reset())}
    onPage={setPage}
    onApplyEnvironment={settings => command(() => api.apply(settings))}
    onApplyStartEnvironment={settings => command(() => api.applyStart(settings))}
    onApplyPauseEnvironment={settings => command(() => api.applyReset(settings))}
  />
  if (page === 'constructor') content = <Constructor state={state} onApply={s => command(() => api.apply(s))} onApplyReset={s => command(() => api.applyReset(s))} onApplyStart={s => command(() => api.applyStart(s))} onSpeed={v => command(() => api.speed(v))} />
  if (page === 'analytics') content = <Analytics state={state} />
  if (page === 'sampling') content = <Sampling state={state} result={seriesResult} onRun={runSeries} busy={seriesBusy} onExport={() => { window.location.href = api.exportSeriesUrl() }} />
  if (page === 'inspector') content = <Inspector state={state} />
  if (page === 'journal') content = <Journal state={state} />
  if (page === 'help') content = <Help />

  return (
    <>
      <Shell page={page} setPage={setPage} state={state} connected={!error} onStart={() => command(api.start)} onPause={() => command(api.pause)} onStep={() => command(() => api.step(1))} onReset={() => command(api.reset)} onExport={() => { window.location.href = api.exportUrl() }}>
        <div className="content-heading-mobile"><span>{pageTitles[page]}</span>{error && <span className="error-badge">{error}</span>}</div>
        {content}
      </Shell>
    </>
  )
}
