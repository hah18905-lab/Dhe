@echo off
setlocal
cd /d "%~dp0"
title ASTRA
echo Starting ASTRA...
echo.
start "ASTRA Backend" cmd /k call "%~dp0run_backend.bat"
timeout /t 3 /nobreak >nul
start "ASTRA Frontend" cmd /k call "%~dp0run_frontend.bat"
timeout /t 7 /nobreak >nul
start "" "http://127.0.0.1:5173"
echo.
echo ASTRA is starting. Do not close the two ASTRA windows.
pause
