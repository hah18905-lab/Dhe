@echo off
setlocal
cd /d "%~dp0backend"
where py >nul 2>&1
if errorlevel 1 (
  set "PY=python"
) else (
  set "PY=py -3"
)
echo Checking Python dependencies...
%PY% -c "import fastapi,uvicorn,pydantic" >nul 2>&1
if errorlevel 1 (
  echo Installing backend dependencies...
  %PY% -m pip install -r requirements.txt
  if errorlevel 1 (echo Backend dependency installation failed.&pause&exit /b 1)
)
echo Starting backend on http://127.0.0.1:8000
%PY% -m uvicorn api:app --host 127.0.0.1 --port 8000
pause
