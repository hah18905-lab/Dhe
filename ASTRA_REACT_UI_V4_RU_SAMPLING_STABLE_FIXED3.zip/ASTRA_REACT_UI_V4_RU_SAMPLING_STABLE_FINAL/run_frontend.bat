@echo off
setlocal
cd /d "%~dp0frontend"
where npm.cmd >nul 2>&1
if errorlevel 1 (
  echo Node.js and npm were not found.
  echo Install Node.js LTS and run this file again.
  pause
  exit /b 1
)
if not exist node_modules (
  echo Installing frontend dependencies...
  call npm.cmd install
  if errorlevel 1 (echo Frontend dependency installation failed.&pause&exit /b 1)
)
echo Starting frontend on http://127.0.0.1:5173
call npm.cmd run dev -- --host 127.0.0.1 --port 5173
pause
