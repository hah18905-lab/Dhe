const API = import.meta.env.VITE_API_URL || 'http://127.0.0.1:8000/api'

async function request(path, options = {}) {
  const response = await fetch(`${API}${path}`, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
  })
  if (!response.ok) {
    const body = await response.text()
    throw new Error(body || `HTTP ${response.status}`)
  }
  return response.json()
}

export const api = {
  state: () => request('/state'),
  start: () => request('/sim/start', { method: 'POST' }),
  pause: () => request('/sim/pause', { method: 'POST' }),
  reset: () => request('/sim/reset', { method: 'POST' }),
  step: (ticks = 1) => request('/sim/step', { method: 'POST', body: JSON.stringify({ ticks }) }),
  speed: (value) => request(`/sim/speed/${value}`, { method: 'POST' }),
  apply: (settings) => request('/planet/apply', { method: 'POST', body: JSON.stringify(settings) }),
  applyReset: (settings) => request('/planet/apply-reset', { method: 'POST', body: JSON.stringify(settings) }),
  storm: (intensity = null) => request('/events/storm', { method: 'POST', body: JSON.stringify({ intensity }) }),
  climate: (delta = null) => request('/events/climate', { method: 'POST', body: JSON.stringify({ delta }) }),
  select: (organismId) => request('/select', { method: 'POST', body: JSON.stringify({ organism_id: organismId }) }),
  exportUrl: () => `${API}/export`,
}
