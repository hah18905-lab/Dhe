import React, { useEffect, useState } from 'react'
import { ActionButton, Section, SliderField, StatusPill } from '../components/Ui'

const fields = [
  ['temperature','Температура','local thermal factor'],
  ['water','Вода','доступность воды'],
  ['resources','Ресурсы','доступность ресурсов'],
  ['radiation','Радиация','экологический риск'],
  ['energy','Доступная энергия','энергетический потенциал'],
  ['stability','Стабильность','устойчивость среды'],
  ['solar_activity','Солнечная активность','частота/сила космических воздействий'],
]

export default function Constructor({ state, onApply, onApplyReset, onSpeed }) {
  const [settings, setSettings] = useState({ ...state.settings, initial_population: state.settings.initial_population ?? 80 })
  useEffect(() => setSettings({ ...state.settings, initial_population: state.settings.initial_population ?? 80 }), [state.settings])
  const set = (key, value) => setSettings(s => ({ ...s, [key]: value }))

  const normalized = {
    ...settings,
    temperature: settings.temperature / 100,
    water: settings.water / 100,
    resources: settings.resources / 100,
    radiation: settings.radiation / 100,
    energy: settings.energy / 100,
    stability: settings.stability / 100,
    solar_activity: settings.solar_activity / 100,
    mutation_strength: settings.mutation_strength / 100,
    initial_population: Math.round(settings.initial_population),
  }

  return (
    <div className="page-grid">
      <div className="hero-row">
        <div><div className="page-kicker">КОНСТРУКТОР · A-17</div><h2 className="page-title">Соберите условия эксперимента</h2><p className="page-description">Здесь меняется математическая среда. Проценты — нормализованные значения 0…1, а не физические единицы.</p></div>
        <StatusPill tone="good">МОДЕЛЬ БЕЗ ИЗМЕНЕНИЯ ЯДРА</StatusPill>
      </div>

      <Section title="Параметры планеты" subtitle="Изменение можно применить сразу или начать новый эксперимент">
        <div className="settings-grid">
          {fields.map(([key, label, hint]) => (
            <SliderField key={key} label={label} value={Math.round((settings[key] ?? 0) * 100)} onChange={v => set(key, v / 100)} hint={hint} />
          ))}
        </div>
      </Section>

      <div className="two-column">
        <Section title="Параметры системы" subtitle="Не изменяют правила модели выбора">
          <SliderField label="Сила мутации" value={Number(settings.mutation_strength ?? 0.055) * 100} max={20} step={0.5} onChange={v => set('mutation_strength', v / 100)} hint="амплитуда случайного изменения генома" />
          <SliderField label="Начальная популяция" value={settings.initial_population ?? 80} max={200} suffix="" onChange={v => set('initial_population', v)} hint="стартовое число организмов" />
          <SliderField label="Скорость симуляции" value={state.speed} max={10} suffix="×" onChange={v => onSpeed(v)} hint="сколько тиков обрабатывается за цикл UI" />
        </Section>
        <Section title="Применение" subtitle="Сначала проверьте значения, затем запускайте эксперимент">
          <div className="apply-card"><span>Текущая среда</span><strong>{state.environmentStatus}</strong><small>Ёмкость среды: {state.planet.capacity} организмов</small></div>
          <div className="button-stack">
            <ActionButton variant="blue" onClick={() => onApply(normalized)}>Применить к планете</ActionButton>
            <ActionButton onClick={() => onApplyReset(normalized)}>Применить и начать заново</ActionButton>
          </div>
          <div className="formula-note"><b>Как это работает</b><p>Параметры входят в разные формулы с разными весами. Поэтому изменение на +10% не означает автоматическое изменение всех метрик на +10%.</p></div>
        </Section>
      </div>
    </div>
  )
}
