import React from 'react'
import PlanetMap from '../components/PlanetMap'
import Chart from '../components/Chart'
import { ActionButton, MetricCard, Progress, Section, StatusPill } from '../components/Ui'

const fmt = value => Number(value || 0).toFixed(2)

export default function Dashboard({ state, onSelect, onStorm, onClimate, onStep, onReset, onPage }) {
  const p = state.planet
  return (
    <div className="page-grid">
      <div className="hero-row">
        <div>
          <div className="page-kicker">ЭКСПЕРИМЕНТ · {state.running ? 'LIVE' : 'IDLE'}</div>
          <h2 className="page-title">Наблюдение за самоорганизацией среды</h2>
          <p className="page-description">Среда → восприятие → выбор → действие → опыт → адаптация → эволюция.</p>
        </div>
        <StatusPill tone={state.environmentStatus === 'БЛАГОПРИЯТНАЯ' ? 'good' : state.environmentStatus === 'КРИТИЧЕСКАЯ' ? 'danger' : 'warn'}>{state.environmentStatus}</StatusPill>
      </div>

      <div className="metric-grid">
        <MetricCard label="Популяция" value={`${p.population} / ${p.capacity}`} detail={`+${p.births} рождений · −${p.deaths} смертей`} icon="◉" />
        <MetricCard label="Поколение" value={p.generation} detail={`тик ${p.tick}`} tone="dark" icon="G" />
        <MetricCard label="Мощность" value={fmt(state.metrics.power)} detail="интегральное состояние" tone="cyan" icon="P" />
        <MetricCard label="Энтропия" value={fmt(state.metrics.entropy)} detail="разнообразие поведения" tone="purple" icon="S" />
      </div>

      <div className="dashboard-main">
        <Section title="Карта планеты" subtitle="18 × 12 клеток · клик по организму открывает профиль" className="map-section">
          <PlanetMap
            cells={state.cells}
            organisms={state.organisms}
            selectedId={state.selectedId}
            onSelect={onSelect}
            onCellClick={(_cell, stack) => {
              if (!stack?.length) return
              const current = stack.findIndex(o => o.id === state.selectedId)
              onSelect(stack[(current + 1) % stack.length].id)
            }}
          />
        </Section>

        <Section title="Состояние среды" subtitle="Нормализованные параметры модели" className="state-section">
          <div className="environment-bars">
            <Progress label="Температура" value={p.temperature} />
            <Progress label="Вода" value={p.water} />
            <Progress label="Ресурсы" value={p.resources} />
            <Progress label="Радиация" value={p.radiation} />
            <Progress label="Стабильность" value={p.stability} />
            <Progress label="Солнечная активность" value={p.solarActivity} />
          </div>
          <div className="event-box"><span>СОБЫТИЕ</span><b>{p.event || 'Нет активного события'}</b></div>
          <div className="button-grid">
            <ActionButton onClick={onStep}>⏭ Один шаг</ActionButton>
            <ActionButton onClick={onReset}>⟳ Новый эксперимент</ActionButton>
            <ActionButton onClick={() => onStorm()} variant="blue">☀ Солнечная буря</ActionButton>
            <ActionButton onClick={() => onClimate()} variant="danger-soft">☄ Смещение климата</ActionButton>
          </div>
          <button className="text-link" onClick={() => onPage('constructor')}>Открыть конструктор условий →</button>
        </Section>
      </div>

      <Section title="Динамика" subtitle="Популяция, экологическая ёмкость и поколения во времени">
        <Chart history={state.history} />
      </Section>
    </div>
  )
}
