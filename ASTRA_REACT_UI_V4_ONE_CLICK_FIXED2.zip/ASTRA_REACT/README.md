# ASTRA — React UI + Python simulation core

Современный интерфейс ASTRA построен на React, при этом сбалансированное ядро **V4** вынесено в отдельный модуль Python и не переписано под UI.

## Архитектура

```text
ASTRA/
├─ backend/
│  ├─ engine.py        # Планета, организмы, геном, выбор, баланс, эволюция, метрики
│  ├─ api.py           # HTTP API между React и движком
│  └─ requirements.txt
├─ frontend/
│  ├─ package.json
│  ├─ vite.config.js
│  └─ src/
│     ├─ App.jsx       # состояние приложения и связь с API
│     ├─ api.js        # HTTP-команды
│     ├─ styles.css    # дизайн-система ASTRA
│     ├─ components/
│     │  ├─ Shell.jsx
│     │  ├─ PlanetMap.jsx
│     │  ├─ Chart.jsx
│     │  └─ Ui.jsx
│     └─ pages/
│        ├─ Dashboard.jsx
│        ├─ Constructor.jsx
│        ├─ Analytics.jsx
│        ├─ Inspector.jsx
│        ├─ Journal.jsx
│        └─ Help.jsx
├─ legacy_astra_v4_balanced.py # исходный Tkinter V4 для резервного сравнения
└─ README.md
```

## Запуск

### 1. Backend

```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
uvicorn api:app --reload --host 127.0.0.1 --port 8000
```

### 2. Frontend

В отдельном терминале:

```bash
cd frontend
npm install
npm run dev
```

Открой адрес Vite, обычно `http://127.0.0.1:5173`.

## Что сохранилось

Сохранено ядро последнего сбалансированного V4: карта 18×12, биомы, организмы, память, геном, адаптация, мутация, размножение, экологическая ёмкость, баланс популяции, солнечные бури, климатические сдвиги, выбор действий, метрики, история и JSON-экспорт.

React-слой добавляет разнесение функций по понятным экранам:

- **Обзор** — карта, состояние планеты, быстрые действия, график.
- **Конструктор** — все параметры и применение условий.
- **Аналитика** — метрики, стратегии и сравнение снимков.
- **Сущность** — организм и его геном.
- **Журнал** — события по тикам.
- **Справка** — объяснение модели.

Основные цвета интерфейса: `#0E79B2`, `#191923`, `#FBFEF9`.


## Быстрый запуск
Дважды нажмите `START_ASTRA.bat`. Скрипт ждёт готовности backend/frontend перед открытием браузера.

## Если появляется `Failed to fetch`
1. Не закрывайте окно `ASTRA Backend`.
2. Откройте `http://127.0.0.1:8000/api/health`. Должен быть JSON со статусом `ok`.
3. Затем откройте `http://127.0.0.1:5173`.
4. В новой версии React использует Vite proxy `/api`, поэтому CORS/различие localhost и 127.0.0.1 не должны ломать соединение.
