@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
title ASTRA - ПРОВЕРКА ЗАПУСКА

echo.
echo ==================================================
echo       ASTRA — ДИАГНОСТИКА ЗАПУСКА
echo ==================================================
echo.
where py >nul 2>nul
if errorlevel 1 (echo [НЕТ] Python launcher) else (py -3 --version)
where python >nul 2>nul
if errorlevel 1 (echo [НЕТ] python в PATH) else (python --version)
where npm >nul 2>nul
if errorlevel 1 (echo [НЕТ] npm) else (npm --version)
where node >nul 2>nul
if errorlevel 1 (echo [НЕТ] node) else (node --version)

echo.
if exist "backend\.venv\Scripts\python.exe" (echo [OK] backend\.venv найден) else (echo [!] backend\.venv отсутствует — START_ASTRA создаст его)
if exist "frontend\node_modules\.bin\vite.cmd" (echo [OK] Vite найден) else (echo [!] Vite отсутствует — START_ASTRA установит зависимости)

if exist "backend\.venv\Scripts\python.exe" (
  "backend\.venv\Scripts\python.exe" -c "import fastapi,uvicorn,pydantic; print('[OK] FastAPI/Uvicorn/Pydantic')" 2>nul
  if errorlevel 1 echo [!] Python-зависимости отсутствуют
)

echo.
echo Проверка портов 8000 и 5173...
powershell -NoProfile -ExecutionPolicy Bypass -Command "foreach($p in 8000,5173){try{$c=Get-NetTCPConnection -LocalPort $p -State Listen -ErrorAction Stop; Write-Host ('[ЗАНЯТ] Порт '+$p+' PID '+$c.OwningProcess)}catch{Write-Host ('[СВОБОДЕН] Порт '+$p)}}"
echo.
echo Если здесь есть ошибка, пришлите скрин этого окна.
pause
