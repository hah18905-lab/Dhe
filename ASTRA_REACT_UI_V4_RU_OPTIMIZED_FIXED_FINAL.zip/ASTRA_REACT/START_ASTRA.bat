@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul
cd /d "%~dp0"

title ASTRA - ЗАПУСК

echo.
echo ==================================================
echo             ASTRA — БЕЗОПАСНЫЙ ЗАПУСК
echo ==================================================
echo.

REM ===== Python =====
set "PY="
where py >nul 2>nul
if not errorlevel 1 set "PY=py -3"
if not defined PY (
    where python >nul 2>nul
    if not errorlevel 1 set "PY=python"
)
if not defined PY (
    echo [ОШИБКА] Python не найден.
    echo Установите Python 3.11+ и добавьте его в PATH.
    echo.
    pause
    exit /b 1
)
echo [OK] %PY%

REM ===== Node/npm =====
set "NPM=npm.cmd"
where npm >nul 2>nul
if errorlevel 1 (
    echo [ОШИБКА] npm не найден.
    echo Установите Node.js LTS ^(Node 18+^) и перезапустите.
    echo.
    pause
    exit /b 1
)
echo [OK] npm найден.

REM ===== Python venv =====
echo.
echo [1/5] Проверка Python-окружения...
if not exist "backend\.venv\Scripts\python.exe" (
    %PY% -m venv "backend\.venv"
)
if not exist "backend\.venv\Scripts\python.exe" (
    echo [ОШИБКА] Не удалось создать backend\.venv.
    echo Запустите ПРОВЕРКА_ЗАПУСКА.bat для диагностики.
    pause
    exit /b 1
)
set "ASTRA_PY=%~dp0backend\.venv\Scripts\python.exe"

REM ===== Backend deps only when really needed =====
echo [2/5] Проверка зависимостей ядра...
%ASTRA_PY% -c "import fastapi,uvicorn,pydantic" >nul 2>nul
if errorlevel 1 (
    echo [INFO] Устанавливаем зависимости ядра...
    %ASTRA_PY% -m pip install --disable-pip-version-check -r "backend\requirements.txt"
    if errorlevel 1 (
        echo [ОШИБКА] Не удалось установить Python-зависимости.
        echo Проверьте интернет или выполните установку вручную.
        pause
        exit /b 1
    )
) else (
    echo [OK] Зависимости ядра уже установлены.
)

REM ===== Frontend deps only when vite is absent =====
echo.
echo [3/5] Проверка интерфейса...
if not exist "frontend\node_modules\.bin\vite.cmd" (
    echo [INFO] Первый запуск: устанавливаем React/Vite...
    pushd "frontend"
    call %NPM% install --no-audit --no-fund --progress=false
    set "NPM_EXIT=!errorlevel!"
    popd
    if not "!NPM_EXIT!"=="0" (
        echo.
        echo [ОШИБКА] Не удалось установить зависимости интерфейса.
        echo Проверьте интернет и права доступа к папке проекта.
        echo.
        echo Можно повторить запуск после установки Node.js LTS.
        pause
        exit /b 1
    )
) else (
    echo [OK] React/Vite уже установлены.
)

REM ===== Backend: reuse healthy process if one already exists =====
echo.
echo [4/5] Запуск симуляционного ядра...
powershell -NoProfile -ExecutionPolicy Bypass -Command "try { $r=Invoke-WebRequest -UseBasicParsing -TimeoutSec 1 http://127.0.0.1:8000/api/health; if($r.StatusCode -eq 200){exit 0}else{exit 1} } catch { exit 1 }" >nul 2>nul
if errorlevel 1 (
    start "ASTRA — Ядро" cmd /k "cd /d ""%~dp0backend"" && ""%ASTRA_PY%"" -m uvicorn api:app --host 127.0.0.1 --port 8000"
    set "READY="
    for /L %%I in (1,1,40) do (
        powershell -NoProfile -ExecutionPolicy Bypass -Command "try { $r=Invoke-WebRequest -UseBasicParsing -TimeoutSec 1 http://127.0.0.1:8000/api/health; if($r.StatusCode -eq 200){exit 0}else{exit 1} } catch { exit 1 }" >nul 2>nul
        if not errorlevel 1 (set "READY=1" & goto backend_ready)
        timeout /t 1 /nobreak >nul
    )
    if not defined READY (
        echo [ОШИБКА] Ядро не запустилось за 40 секунд.
        echo Посмотрите окно «ASTRA — Ядро» — там будет точная причина.
        pause
        exit /b 1
    )
) else (
    echo [OK] Ядро уже запущено.
)
:backend_ready
echo [OK] Ядро доступно.

REM ===== Frontend =====
echo.
echo [5/5] Запуск интерфейса...
powershell -NoProfile -ExecutionPolicy Bypass -Command "try { $r=Invoke-WebRequest -UseBasicParsing -TimeoutSec 1 http://127.0.0.1:5173; if($r.StatusCode -ge 200 -and $r.StatusCode -lt 500){exit 0}else{exit 1} } catch { exit 1 }" >nul 2>nul
if errorlevel 1 (
    start "ASTRA — Интерфейс" cmd /k "cd /d ""%~dp0frontend"" && call npm.cmd run dev -- --host 127.0.0.1 --port 5173"
    set "READY="
    for /L %%I in (1,1,30) do (
        powershell -NoProfile -ExecutionPolicy Bypass -Command "try { $r=Invoke-WebRequest -UseBasicParsing -TimeoutSec 1 http://127.0.0.1:5173; if($r.StatusCode -ge 200 -and $r.StatusCode -lt 500){exit 0}else{exit 1} } catch { exit 1 }" >nul 2>nul
        if not errorlevel 1 (set "READY=1" & goto frontend_ready)
        timeout /t 1 /nobreak >nul
    )
    if not defined READY echo [ПРЕДУПРЕЖДЕНИЕ] Интерфейс ещё запускается. Проверьте окно «ASTRA — Интерфейс».
) else (
    echo [OK] Интерфейс уже запущен.
)
:frontend_ready
start "" "http://127.0.0.1:5173"
echo.
echo ==================================================
echo              ASTRA ГОТОВА К РАБОТЕ
echo ==================================================
echo.
pause
