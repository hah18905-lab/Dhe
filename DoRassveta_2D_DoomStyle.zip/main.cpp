
#include <SFML/Graphics.hpp>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

using namespace sf;

static constexpr int SW = 960;
static constexpr int SH = 540;
static constexpr int MAP_W = 24;
static constexpr int MAP_H = 24;
static constexpr int RAYS = SW;

const std::vector<std::string> MAP = {
"########################",
"#..........#...........#",
"#..........#...........#",
"#..........#...........#",
"#....######...........##",
"#....#................#",
"#....#................#",
"#....#.....####.......#",
"#..........#..........#",
"#..........#..........#",
"###........#..........#",
"#.....................#",
"#.....................#",
"#.........####........#",
"#.........#..#........#",
"#.........#..#........#",
"#.....................#",
"#....###########......#",
"#.....................#",
"#.....................#",
"#..........#..........#",
"#..........#..........#",
"#.....................#",
"########################"
};

struct Player {
    double x=3.5, y=3.5, a=0.0;
    int hp=100, fear=0, battery=100;
    bool flashlight=true, fire=true;
};

struct Monster {
    double x=14.5, y=10.5;
    double speed=0.72;
    int frame=0;
    bool alive=true;
};

sf::Texture wallTex, floorTex, ceilTex, monsterTex, fireTex;
sf::Sprite wallSprite, monsterSprite, fireSprite;

Player p;
Monster m;

double gameMinutes = 22.0 * 60.0;
double eventTimer = 0.0;
double monsterTimer = 0.0;
double fireTimer = 0.0;
bool gameOver=false;
std::string message = "Survive until 06:00. Press H for rules.";

double normAngle(double a) {
    while(a > M_PI) a -= 2*M_PI;
    while(a < -M_PI) a += 2*M_PI;
    return a;
}

bool solid(double x, double y) {
    int mx=(int)x, my=(int)y;
    if(mx<0||my<0||mx>=MAP_W||my>=MAP_H) return true;
    return MAP[my][mx]=='#';
}

void movePlayer(double dx,double dy) {
    double nx=p.x+dx, ny=p.y+dy;
    if(!solid(nx,p.y)) p.x=nx;
    if(!solid(p.x,ny)) p.y=ny;
}

void addFear(int v) {
    p.fear=std::clamp(p.fear+v,0,100);
    if(p.fear>=100) {
        gameOver=true;
        message="YOU LOST YOUR MIND.";
    }
}

void damage(int v) {
    p.hp-=v;
    if(p.hp<=0) {
        p.hp=0; gameOver=true;
        message="THE FOREST TOOK YOU.";
    }
}

std::string clockText() {
    int mins=(int)gameMinutes;
    int h=(mins/60)%24, mm=mins%60;
    char buf[16];
    std::snprintf(buf,sizeof(buf),"%02d:%02d",h,mm);
    return buf;
}

// 5x7 bitmap font, enough for HUD.
const std::vector<std::pair<char,std::vector<std::string>>> FONT = {
{'A',{"01110","10001","10001","11111","10001","10001","10001"}},
{'B',{"11110","10001","10001","11110","10001","10001","11110"}},
{'C',{"01111","10000","10000","10000","10000","10000","01111"}},
{'D',{"11110","10001","10001","10001","10001","10001","11110"}},
{'E',{"11111","10000","10000","11110","10000","10000","11111"}},
{'F',{"11111","10000","10000","11110","10000","10000","10000"}},
{'G',{"01111","10000","10000","10111","10001","10001","01111"}},
{'H',{"10001","10001","10001","11111","10001","10001","10001"}},
{'I',{"11111","00100","00100","00100","00100","00100","11111"}},
{'J',{"00111","00010","00010","00010","10010","10010","01100"}},
{'K',{"10001","10010","10100","11000","10100","10010","10001"}},
{'L',{"10000","10000","10000","10000","10000","10000","11111"}},
{'M',{"10001","11011","10101","10101","10001","10001","10001"}},
{'N',{"10001","11001","10101","10011","10001","10001","10001"}},
{'O',{"01110","10001","10001","10001","10001","10001","01110"}},
{'P',{"11110","10001","10001","11110","10000","10000","10000"}},
{'R',{"11110","10001","10001","11110","10100","10010","10001"}},
{'S',{"01111","10000","10000","01110","00001","00001","11110"}},
{'T',{"11111","00100","00100","00100","00100","00100","00100"}},
{'U',{"10001","10001","10001","10001","10001","10001","01110"}},
{'V',{"10001","10001","10001","10001","10001","01010","00100"}},
{'W',{"10001","10001","10001","10101","10101","11011","10001"}},
{'Y',{"10001","10001","01010","00100","00100","00100","00100"}},
{'0',{"01110","10001","10011","10101","11001","10001","01110"}},
{'1',{"00100","01100","00100","00100","00100","00100","01110"}},
{'2',{"01110","10001","00001","00010","00100","01000","11111"}},
{'3',{"11110","00001","00001","01110","00001","00001","11110"}},
{'4',{"00010","00110","01010","10010","11111","00010","00010"}},
{'5',{"11111","10000","10000","11110","00001","00001","11110"}},
{'6',{"01110","10000","10000","11110","10001","10001","01110"}},
{'7',{"11111","00001","00010","00100","01000","01000","01000"}},
{'8',{"01110","10001","10001","01110","10001","10001","01110"}},
{'9',{"01110","10001","10001","01111","00001","00001","01110"}},
{':',{"00000","00100","00100","00000","00100","00100","00000"}},
{'%',{"11001","11010","00100","01000","10110","10011","00000"}},
{' ',{"00000","00000","00000","00000","00000","00000","00000"}},
{'.',{"00000","00000","00000","00000","00000","01100","01100"}}
};

void text(RenderWindow& win, std::string s, int x, int y, int scale=3) {
    for(char c: s) {
        c=(char)std::toupper((unsigned char)c);
        auto it=std::find_if(FONT.begin(),FONT.end(),[&](auto &q){return q.first==c;});
        if(it!=FONT.end()) {
            for(int yy=0;yy<7;yy++) for(int xx=0;xx<5;xx++)
                if(it->second[yy][xx]=='1') {
                    RectangleShape r(Vector2f((float)scale,(float)scale));
                    r.setPosition((float)(x+xx*scale),(float)(y+yy*scale));
                    r.setFillColor(Color::White);
                    win.draw(r);
                }
        }
        x += 6*scale;
    }
}

void renderWorld(RenderWindow& win) {
    // sky
    RectangleShape sky(Vector2f(SW,SH/2));
    sky.setFillColor(Color(12,19,25));
    win.draw(sky);

    // floor
    RectangleShape ground(Vector2f(SW,SH/2));
    ground.setPosition(0,SH/2);
    ground.setFillColor(Color(34,38,28));
    win.draw(ground);

    std::vector<double> zbuf(SW);

    for(int x=0;x<SW;x++) {
        double cam=(2.0*x/SW)-1.0;
        double rayA=p.a + cam*(M_PI/3.0)/2.0;
        double rx=std::cos(rayA), ry=std::sin(rayA);
        int mx=(int)p.x, my=(int)p.y;
        double deltaX=(rx==0)?1e30:std::abs(1/rx);
        double deltaY=(ry==0)?1e30:std::abs(1/ry);
        int stepX=rx<0?-1:1, stepY=ry<0?-1:1;
        double sideX=rx<0?(p.x-mx)*deltaX:(mx+1.0-p.x)*deltaX;
        double sideY=ry<0?(p.y-my)*deltaY:(my+1.0-p.y)*deltaY;
        int side=0;
        bool hit=false;
        for(int i=0;i<64 && !hit;i++) {
            if(sideX<sideY){sideX+=deltaX;mx+=stepX;side=0;}
            else {sideY+=deltaY;my+=stepY;side=1;}
            if(mx<0||my<0||mx>=MAP_W||my>=MAP_H){hit=true;break;}
            if(MAP[my][mx]=='#') hit=true;
        }
        double dist=(side==0?sideX-deltaX:sideY-deltaY);
        dist*=std::cos(rayA-p.a);
        dist=std::max(0.05,dist);
        zbuf[x]=dist;
        int line=(int)(SH/dist);
        int start=std::max(0,SH/2-line/2), end=std::min(SH-1,SH/2+line/2);
        int texX=(int)(128*(side==0?(p.y+dist*ry):(p.x+dist*rx)))%128;
        if(texX<0) texX+=128;

        // Sample wall texture by drawing 1px vertical slices.
        Sprite s(wallTex);
        s.setTextureRect(IntRect(texX,0,1,128));
        s.setPosition((float)x,(float)start);
        s.setScale(1.f,(float)(end-start+1)/128.f);
        Color tint = (dist>8)?Color(55,55,55):Color(180,180,180);
        if(side==1) tint=Color(tint.r*0.75f,tint.g*0.75f,tint.b*0.75f);
        s.setColor(tint);
        win.draw(s);
    }

    // billboard monster
    double dx=m.x-p.x, dy=m.y-p.y;
    double dist=std::sqrt(dx*dx+dy*dy);
    double ang=normAngle(std::atan2(dy,dx)-p.a);
    if(std::abs(ang)<M_PI/3.0 && dist>0.3) {
        int sx=(int)(SW/2 + std::tan(ang)*SW*0.82);
        int h=(int)(SH/dist*0.75);
        int w=h*2/3;
        int left=sx-w/2, top=SH/2-h/2;
        int frame=(int)(gameMinutes*2)%4;
        Sprite s(monsterTex);
        s.setTextureRect(IntRect(frame*96,0,96,144));
        s.setPosition((float)left,(float)top);
        s.setScale((float)w/96.f,(float)h/144.f);
        Color tint= dist>7?Color(70,70,70):Color(220,220,220);
        if(!p.flashlight || p.battery<=0) tint=Color(75,75,75);
        s.setColor(tint);
        if(left+w>0 && left<SW && dist<zbuf[std::clamp(sx,0,SW-1)]+1.0)
            win.draw(s);
    }

    // muzzle/hand-like flashlight beam
    if(p.flashlight && p.battery>0) {
        CircleShape vignette(260);
        vignette.setOrigin(260,260);
        vignette.setPosition(SW/2.f,SH/2.f);
        vignette.setFillColor(Color(255,255,210,18));
        win.draw(vignette);
    }

    // HUD
    RectangleShape hud(Vector2f(SW,76));
    hud.setPosition(0,SH-76);
    hud.setFillColor(Color(5,7,7,225));
    win.draw(hud);
    text(win,"HP "+std::to_string(p.hp),18,SH-66,3);
    text(win,"FEAR "+std::to_string(p.fear)+"%",170,SH-66,3);
    text(win,"BAT "+std::to_string(p.battery)+"%",390,SH-66,3);
    text(win,"TIME "+clockText(),600,SH-66,3);
    text(win,p.fire?"FIRE OK":"FIRE OUT",800,SH-66,2);

    text(win,"WASD MOVE  MOUSE LOOK  F FLASHLIGHT  H RULES  ESC QUIT",18,SH-25,2);
}

void eventTick() {
    if(eventTimer>0) return;
    int r=std::rand()%100;
    eventTimer=6.0;
    if(r<18) {
        addFear(4);
        message="A BRANCH SNAPS BEHIND YOU.";
    } else if(r<32) {
        addFear(8);
        message="SOMEONE WHISPERS YOUR NAME.";
    } else if(r<42) {
        message="THREE KNOCKS. SOMEWHERE NEARBY.";
    } else if(r<52) {
        addFear(6);
        message="A LIGHT MOVES BETWEEN THE TREES.";
    } else if(r<62) {
        message="YOU HEAR SLOW BREATHING.";
        m.speed=0.85;
    } else {
        message="THE FOREST IS SILENT.";
    }
}

void updateMonster(double dt) {
    if(!m.alive) return;
    double dx=p.x-m.x, dy=p.y-m.y;
    double dist=std::sqrt(dx*dx+dy*dy);
    if(dist<9.0) {
        double vx=dx/dist, vy=dy/dist;
        double speed=m.speed*(p.fire?0.45:1.0);
        double nx=m.x+vx*speed*dt, ny=m.y+vy*speed*dt;
        if(!solid(nx,m.y)) m.x=nx;
        if(!solid(m.x,ny)) m.y=ny;
        if(dist<0.85) {
            damage(15);
            addFear(12);
            m.x -= vx*1.2; m.y -= vy*1.2;
            message="THE THING ATTACKED YOU.";
        }
    }
}

int main() {
    std::srand((unsigned)std::time(nullptr));

    if(!wallTex.loadFromFile("assets/wall.png") ||
       !floorTex.loadFromFile("assets/floor.png") ||
       !ceilTex.loadFromFile("assets/ceiling.png") ||
       !monsterTex.loadFromFile("assets/monster.png") ||
       !fireTex.loadFromFile("assets/fire.png")) {
        std::cerr<<"Could not load assets. Run the executable from the project folder.\n";
        return 1;
    }

    RenderWindow window(VideoMode(SW,SH),"DO RASSVETA - 2D RAYCAST HORROR");
    window.setFramerateLimit(60);
    window.setMouseCursorVisible(false);
    window.setMouseCursorGrabbed(true);
    Mouse::setPosition(Vector2i(SW/2,SH/2),window);

    Clock clock;

    while(window.isOpen()) {
        double dt=clock.restart().asSeconds();
        dt=std::min(dt,0.05);

        Event ev;
        while(window.pollEvent(ev)) {
            if(ev.type==Event::Closed) window.close();
            if(ev.type==Event::KeyPressed && ev.key.code==Keyboard::Escape) window.close();
            if(ev.type==Event::KeyPressed && ev.key.code==Keyboard::F) {
                p.flashlight=!p.flashlight;
            }
            if(ev.type==Event::KeyPressed && ev.key.code==Keyboard::H) {
                std::cout<<"\nRULES:\n1. Do not enter deep forest after midnight.\n2. Never answer your name.\n3. Do not approach a person on the clearing.\n4. Do not follow lights.\n5. Do not look into the house windows after midnight.\n6. Never open a door after three knocks.\n7. At 03:00 make sure the fire still burns.\n\n";
                message="RULES PRINTED TO CONSOLE.";
            }
        }

        if(!gameOver) {
            // Mouse look
            Vector2i mp=Mouse::getPosition(window);
            int dx=mp.x-SW/2;
            p.a += dx*0.0027;
            Mouse::setPosition(Vector2i(SW/2,SH/2),window);

            double speed=2.0*dt*(Keyboard::isKeyPressed(Keyboard::LShift)?1.55:1.0);
            double fx=std::cos(p.a), fy=std::sin(p.a);
            double rx=-fy, ry=fx;
            if(Keyboard::isKeyPressed(Keyboard::W)) movePlayer(fx*speed,fy*speed);
            if(Keyboard::isKeyPressed(Keyboard::S)) movePlayer(-fx*speed,-fy*speed);
            if(Keyboard::isKeyPressed(Keyboard::A)) movePlayer(-rx*speed,-ry*speed);
            if(Keyboard::isKeyPressed(Keyboard::D)) movePlayer(rx*speed,ry*speed);

            gameMinutes += dt*3.0; // 20 real seconds ~= 1 game minute
            eventTimer-=dt;
            eventTick();
            updateMonster(dt);

            if(p.flashlight && p.battery>0 && Keyboard::isKeyPressed(Keyboard::Space))
                p.battery=std::max(0,p.battery-(int)(dt*5));

            if(gameMinutes>=360.0) { // 06:00
                gameOver=true;
                message=(p.fire && p.fear<80)?"SUNRISE. YOU SURVIVED.":"SUNRISE. BUT SOMETHING FOLLOWED YOU.";
            }

            // Fire slowly weakens after 03:00
            if(gameMinutes>=180.0) {
                fireTimer+=dt;
                if(fireTimer>25.0 && p.fire) {
                    p.fire=false;
                    message="THE CAMPFIRE HAS GONE OUT.";
                }
            }
        }

        window.clear();
        renderWorld(window);

        if(!message.empty()) {
            RectangleShape box(Vector2f(700,42));
            box.setPosition(130,18);
            box.setFillColor(Color(0,0,0,170));
            window.draw(box);
            text(window,message,145,30,2);
        }

        if(gameOver) {
            RectangleShape overlay(Vector2f(SW,SH));
            overlay.setFillColor(Color(0,0,0,170));
            window.draw(overlay);
            std::string title = (gameMinutes>=360.0) ? "06:00" : "GAME OVER";
            text(window,title,SW/2-70,SH/2-25,5);
            text(window,"PRESS ESC TO EXIT",SW/2-120,SH/2+25,3);
        }

        window.display();
    }
    return 0;
}
