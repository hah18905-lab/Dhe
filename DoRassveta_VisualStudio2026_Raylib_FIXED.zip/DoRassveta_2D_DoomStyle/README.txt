DO RASSVETA — Raylib / Visual Studio 2026

1. Установи Raylib через vcpkg:
   cd C:\vcpkg
   .\vcpkg install raylib:x64-windows

2. Открой папку проекта в Visual Studio 2026.
3. Выбери preset: vs-vcpkg.
4. Собери проект (Build -> Build All).
5. Запусти DoRassveta.

Важно: SFML больше не используется. Проект полностью переведён на Raylib.
Рабочая папка — корень проекта, поэтому assets/ находится рядом с main.cpp.
