DO RASSVETA - 2D DOOM-STYLE HORROR
===================================

This version is prepared for Visual Studio 2026 + vcpkg + SFML 3.

1) Install Visual Studio with "Desktop development with C++".
2) Install Git.
3) Open PowerShell and run:

   cd C:\
   git clone https://github.com/microsoft/vcpkg.git
   cd vcpkg
   .\bootstrap-vcpkg.bat
   .\vcpkg install sfml:x64-windows

4) Open the project folder in Visual Studio 2026:
   File -> Open -> Folder -> DoRassveta_2D_DoomStyle

5) Visual Studio should detect CMakePresets.json.
   Select preset "vs-vcpkg" and build the DoRassveta target.

IMPORTANT:
- The project expects vcpkg at C:\vcpkg. If you installed it elsewhere,
  change CMakePresets.json and CMakeLists.txt to your vcpkg path.
- Run the game with the project folder as the working directory so that
  assets/wall.png, assets/monster.png, etc. can be found.

CONTROLS
--------
WASD  - move
SHIFT - run
Mouse - look around
F     - flashlight
H     - print rules to Visual Studio Output/console
ESC   - quit

The game is a 2.5D raycasting prototype: the world is a 2D map rendered
from first person, in the spirit of old Doom/Wolfenstein-style games.
