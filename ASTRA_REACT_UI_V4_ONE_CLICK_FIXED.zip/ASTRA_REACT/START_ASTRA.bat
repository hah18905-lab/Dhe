@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"

title ASTRA - ONE CLICK START

echo.
echo ==========================================
echo          ASTRA - ONE CLICK START
echo ==========================================
echo.

REM ----------------------------------------------------------
REM Find Python. Prefer the Windows Python launcher (py),
REM because "python" may point to the Microsoft Store alias.
REM ----------------------------------------------------------
set "PY="
where py >nul 2>nul
if not errorlevel 1 set "PY=py -3"

if not defined PY (
    where python >nul 2>nul
    if not errorlevel 1 set "PY=python"
)

if not defined PY (
    echo [ERROR] Python not found.
    echo.
    echo Install Python 3.11+ from python.org and enable:
    echo   Add Python to PATH
    echo.
    pause
    exit /b 1
)

echo Python: %PY%

REM ----------------------------------------------------------
REM Node / npm
REM ----------------------------------------------------------
where npm >nul 2>nul
if errorlevel 1 (
    echo.
    echo [ERROR] Node.js / npm not found.
    echo Install Node.js LTS and run this file again.
    pause
    exit /b 1
)

echo Node/npm: OK

echo.
echo [1/4] Preparing Python environment...

REM Try a virtual environment first.
if not exist "backend\.venv\Scripts\python.exe" (
    %PY% -m venv "backend\.venv" >nul 2>&1
)

REM If venv failed, do NOT stop the whole application.
REM Fall back to system Python. This is useful on PCs where
REM Python was installed without the venv component.
if exist "backend\.venv\Scripts\python.exe" (
    set "ASTRA_PY=backend\.venv\Scripts\python.exe"
    echo Virtual environment: OK
) else (
    set "ASTRA_PY=%PY%"
    echo [WARNING] Could not create virtual environment.
    echo [WARNING] Using installed Python directly instead.
)

REM ----------------------------------------------------------
REM Make sure pip exists.
REM ----------------------------------------------------------
%ASTRA_PY% -m pip --version >nul 2>&1
if errorlevel 1 (
    echo.
    echo [INFO] pip is missing. Trying to enable it...
    %ASTRA_PY% -m ensurepip --upgrade
    if errorlevel 1 (
        echo.
        echo [ERROR] Could not enable pip.
        echo Reinstall Python from python.org with pip enabled.
        pause
        exit /b 1
    )
)

echo.
echo [2/4] Checking Python dependencies...
%ASTRA_PY% -m pip install -r "backend\requirements.txt"
if errorlevel 1 (
    echo.
    echo [ERROR] Python dependency installation failed.
    echo Check your Internet connection and try again.
    pause
    exit /b 1
)

echo.
echo [3/4] Checking React dependencies...
if not exist "frontend\node_modules" (
    cd /d "%~dp0frontend"
    call npm install
    if errorlevel 1 (
        echo.
        echo [ERROR] React dependency installation failed.
        pause
        exit /b 1
    )
    cd /d "%~dp0"
) else (
    echo React dependencies: OK
)

echo.
echo [4/4] Starting ASTRA...

start "ASTRA Backend" cmd /k "cd /d "%~dp0backend" && "%ASTRA_PY%" -m uvicorn api:app --host 127.0.0.1 --port 8000"
start "ASTRA Frontend" cmd /k "cd /d "%~dp0frontend" && npm run dev"

echo.
echo Waiting for ASTRA...
timeout /t 4 /nobreak >nul
start "" "http://127.0.0.1:5173"

echo.
echo ==========================================
echo ASTRA is starting!
echo http://127.0.0.1:5173
echo ==========================================
echo.
echo Keep the two ASTRA terminal windows open.
echo.
pause
